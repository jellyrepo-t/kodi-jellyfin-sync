"""
Přehrávač pro TMDb Helper: tlačítko „Přehrát“ u filmu nebo epizody z TMDb najde položku na
Jellyfinu podle TMDb ID (případně nabídne verze) a přehraje ji.

TMDb Helper čte přehrávače (JSON) ze složky addon_data/plugin.video.themoviedb.helper/players/.
Služba addonu tam při startu zapíše (nebo aktualizuje) soubor jellyfin_sync.json.
"""
import json
import os

import xbmc

try:
    import xbmcvfs
    _translate = xbmcvfs.translatePath
except (ImportError, AttributeError):                 # starší Kodi
    _translate = xbmc.translatePath

TMDBHELPER_ID = 'plugin.video.themoviedb.helper'
PLAYERS_DIR = 'special://profile/addon_data/plugin.video.themoviedb.helper/players/'
FILENAME = 'jellyfin_sync.json'
BASE = 'plugin://plugin.video.jellyfin_sync/?action=play_tmdb'

PLAYER = {
    "name": "Jellyfin Sync",
    "plugin": "plugin.video.jellyfin_sync",
    "priority": 100,
    "is_resolvable": "true",
    "play_movie": BASE + "&type=movie&tmdb={tmdb}&imdb={imdb}&year={year}",
    "play_episode": BASE + "&type=episode&tmdb={tmdb}&tvdb={tvdb}&season={season}&episode={episode}",
}


def player_path():
    return os.path.join(_translate(PLAYERS_DIR), FILENAME)


# Nastavení TMDb Helperu, která doplněk nastaví (jen pokud mají výchozí hodnotu – vlastní volbu nepřepíše)
SETTINGS = {
    # „Get additional details from the local Kodi library database“: 0 = ne, 1 = Supplement, 2 = Preferred
    # Preferred: filmy z knihovny (= z Jellyfinu) se v TMDb seznamech ukážou jako vlastněné, s údaji z knihovny
    'use_kodi_local_db': ('2', ('', '0')),
}


def configure_settings():
    """Nastaví doporučené volby TMDb Helperu. Vrací seznam změněných nastavení."""
    import xbmcaddon
    changed = []
    try:
        helper = xbmcaddon.Addon(TMDBHELPER_ID)
    except Exception:
        return changed
    for key, (value, defaults) in SETTINGS.items():
        if helper.getSetting(key) in defaults:
            helper.setSetting(key, value)
            changed.append(key)
    if changed:
        xbmc.log('[JellyfinSync] TMDb Helper nastaven: {}'.format(', '.join(changed)), xbmc.LOGINFO)
    return changed


def install(force=False):
    """Zapíše přehrávač (a doporučená nastavení), pokud je TMDb Helper nainstalovaný.
    Vrací True, když soubor přehrávače změnil."""
    try:
        if not force and not xbmc.getCondVisibility('System.HasAddon({})'.format(TMDBHELPER_ID)):
            return False
    except Exception:
        return False
    try:
        configure_settings()
    except Exception as e:
        xbmc.log('[JellyfinSync] Nastaveni TMDb Helperu: {}'.format(e), xbmc.LOGWARNING)
    path = player_path()
    content = json.dumps(PLAYER, indent=4, ensure_ascii=False)
    try:
        with open(path, encoding='utf-8') as f:
            if f.read() == content:
                return False
    except (OSError, IOError):
        pass
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(content)
    xbmc.log('[JellyfinSync] Prehravac pro TMDb Helper zapsan: ' + path, xbmc.LOGINFO)
    return True
