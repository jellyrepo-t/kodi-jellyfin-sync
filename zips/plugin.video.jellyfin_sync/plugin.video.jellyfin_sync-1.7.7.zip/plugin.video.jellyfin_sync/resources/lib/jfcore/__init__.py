"""
jfcore – sdílené jádro pro PC appku (JellyKodiSync) a Kodi addon (plugin.video.jellyfin_sync).

Záměrně jen stdlib (urllib + sqlite3): žádné requests, tkinter ani xbmc,
aby se stejný kód dal spustit na Windows i uvnitř Kodi.

  jfcore.client       Jellyfin klient (přihlášení, API klíč, stránkované položky, diagnostika)
  jfcore.maintenance  údržba Kodi databáze (mrtvá ID, přepis adresy serveru a API klíče)
  jfcore.redact       maskování API klíčů, tokenů a hesel v logu
"""

__version__ = "1.0.0"
