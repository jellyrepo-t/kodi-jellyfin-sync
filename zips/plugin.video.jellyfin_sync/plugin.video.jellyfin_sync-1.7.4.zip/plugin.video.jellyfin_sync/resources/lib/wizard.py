"""
Průvodce prvním spuštěním: adresa serveru, přihlášení (rovnou se ověří), jestli má addon
plnit knihovnu Kodi, a případně první plná synchronizace.

Spustí se sám při otevření addonu, dokud není nastavený server; znovu z menu „Průvodce nastavením“.
"""
import xbmcaddon
import xbmcgui

from resources.lib.sync_engine import load_state, save_state


def normalize_server(url):
    url = (url or '').strip().rstrip('/')
    if url and '://' not in url:
        url = 'https://' + url
    return url


def run(addon=None, start_full_sync=None, choose_skin=True):
    """Vrací True, když se nastavení uložilo. start_full_sync() spustí první plnou synchronizaci."""
    addon = addon or xbmcaddon.Addon()
    dlg = xbmcgui.Dialog()

    server = normalize_server(dlg.input('Jellyfin - adresa serveru (napr. https://jellyfin.example.cz)',
                                        defaultt=addon.getSetting('server_url') or 'https://'))
    if not server or server in ('https:', 'http:'):
        return False
    user = (dlg.input('Jellyfin - uzivatelske jmeno', defaultt=addon.getSetting('username')) or '').strip()
    if not user:
        return False
    password = dlg.input('Jellyfin - heslo', option=xbmcgui.ALPHANUM_HIDE_INPUT) or ''

    from resources.lib.jellyfin import JellyfinClient
    try:
        JellyfinClient(server, user, password).login()
    except Exception as e:
        dlg.ok('Jellyfin - prihlaseni selhalo', 'Server: {}\n{}'.format(server, e))
        return False

    sync_here = dlg.yesno(
        'Jellyfin - knihovna Kodi',
        'Ma tento doplnek plnit knihovnu Kodi filmy a serialy z Jellyfinu?\n\n'
        'Ne = knihovnu plni jina aplikace (napr. PC appka JellyKodiSync); doplnek pak slouzi '
        'jen pro vyber verzi a prehravani z TMDb.')

    if server != addon.getSetting('server_url'):          # jiný server -> starý API klíč neplatí
        state = load_state()
        for key in ('api_key', 'user_id'):
            state.pop(key, None)
        save_state(state)
    addon.setSetting('server_url', server)
    addon.setSetting('username', user)
    addon.setSetting('password', password)
    addon.setSetting('auto_sync', 'true' if sync_here else 'false')
    addon.setSetting('auto_cleanup', 'true' if sync_here else 'false')

    if sync_here and start_full_sync and dlg.yesno(
            'Jellyfin - prvni synchronizace',
            'Prihlaseni funguje. Spustit ted plnou synchronizaci? Bezi na pozadi, Kodi muzes dal pouzivat.'):
        start_full_sync()
    elif not sync_here:
        dlg.ok('Jellyfin - hotovo', 'Prihlaseni funguje. Knihovnu tento doplnek plnit nebude; '
               'na filmu pouzij kontextove menu "Jellyfin - vybrat verzi".')
    try:                                                # Kodi 21.2: zasekávání po zastavení filmu
        from resources.lib import kodi_fixes
        kodi_fixes.offer_fix(dlg)
    except Exception as e:
        import xbmc
        xbmc.log('[JellyfinSync] Oprava HTTP/2: {}'.format(e), xbmc.LOGWARNING)
    if choose_skin:                                     # poslední krok: vzhled (sync mezitím běží na pozadí)
        try:
            from resources.lib import skin_setup
            skin_setup.run_interactive()
        except Exception as e:
            import xbmc
            xbmc.log('[JellyfinSync] Vzhled se nepodarilo nastavit: {}'.format(e), xbmc.LOGWARNING)
    return True
