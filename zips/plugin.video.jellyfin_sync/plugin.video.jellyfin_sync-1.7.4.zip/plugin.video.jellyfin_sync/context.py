"""
Kontextové menu filmu: „Jellyfin – vybrat verzi“.

Funguje u filmů z knihovny Kodi i u filmů z TMDb seznamů (TMDb Helper, widgety skinu), které
v knihovně nejsou. Film najde na Jellyfinu podle souboru z knihovny nebo podle TMDb/IMDb ID,
ukáže všechny jeho aktuální verze – i ty, které server doplňuje živě (např. plugin
Webshare/Fastshare) a které proto nejdou uložit do knihovny – a vybranou rovnou přehraje.
"""
import json
import re
import sys

import xbmc
import xbmcgui

VIDEO_ID_RE = re.compile(r'/Videos/([0-9a-f]{32})')


def notify(message, error=False):
    xbmcgui.Dialog().notification(
        'Jellyfin Sync', message,
        xbmcgui.NOTIFICATION_ERROR if error else xbmcgui.NOTIFICATION_INFO, 5000)


def item_id_from_path(path):
    m = VIDEO_ID_RE.search(path or '')
    return m.group(1) if m else None


def movie_file(dbid):
    """Cesta k souboru filmu z knihovny Kodi (přes JSON-RPC) – použije se, když ji položka nenese sama."""
    try:
        reply = xbmc.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0", "id": 1, "method": "VideoLibrary.GetMovieDetails",
            "params": {"movieid": int(dbid), "properties": ["file"]}}))
        return json.loads(reply).get('result', {}).get('moviedetails', {}).get('file', '') or ''
    except Exception as e:
        xbmc.log('[JellyfinSync context] JSON-RPC selhalo: {}'.format(e), xbmc.LOGWARNING)
        return ''


def resolve_path():
    """Adresa souboru vybraného filmu: z položky, jinak podle ID filmu v knihovně (může být prázdná)."""
    path = xbmc.getInfoLabel('ListItem.FileNameAndPath')
    if item_id_from_path(path):
        return path
    dbid = xbmc.getInfoLabel('ListItem.DBID')
    if dbid and str(dbid).isdigit():
        file = movie_file(dbid)
        if item_id_from_path(file):
            return file
    try:
        path = path or sys.listitem.getPath()
    except Exception:
        pass
    return path or ''


def provider_ids():
    """(tmdb, imdb, rok) vybrané položky – z knihovny Kodi i z položek TMDb Helperu."""
    tmdb = xbmc.getInfoLabel('ListItem.UniqueID(tmdb)') or xbmc.getInfoLabel('ListItem.Property(tmdb_id)')
    imdb = xbmc.getInfoLabel('ListItem.UniqueID(imdb)') or xbmc.getInfoLabel('ListItem.IMDBNumber')
    if not (imdb or '').startswith('tt'):
        imdb = ''
    return (tmdb or '').strip(), (imdb or '').strip(), (xbmc.getInfoLabel('ListItem.Year') or '').strip()


def select_and_play(path, tmdb='', imdb='', year=''):
    """Vrací True, když se něco přehrálo."""
    vid = item_id_from_path(path)
    if not (vid or tmdb or imdb):
        notify('Tento film nepochazi z Jellyfinu.', error=True)
        return False

    from resources.lib import picker
    picker.busy(True)                          # první načtení rejstříku chvíli trvá
    try:
        jf = picker.connect()
        group, options = picker.movie_options(jf, vid, tmdb, imdb, year)
    except picker.NotFound as e:
        notify(str(e) if not vid else 'Server k tomuto filmu nevratil zadne verze.', error=bool(vid))
        return False
    except Exception as e:
        xbmc.log('[JellyfinSync context] {}'.format(e), xbmc.LOGWARNING)
        notify('Nelze se pripojit k Jellyfinu: {}'.format(e), error=True)
        return False
    finally:
        picker.busy(False)

    if len(options) < 2 and vid:
        notify('Tento film ma na serveru jen jednu verzi.')
        return False
    source_id = picker.choose(options, picker.HEADING, always_ask=True)
    if source_id is None:
        return False
    url = picker.stream_url(jf, source_id)

    title = xbmc.getInfoLabel('ListItem.Title') or group.primary.get('Name') or ''
    li = xbmcgui.ListItem(label=title, path=url)
    try:
        li.setInfo('video', {'title': title, 'plot': xbmc.getInfoLabel('ListItem.Plot')})
        poster = xbmc.getInfoLabel('ListItem.Art(poster)')
        if poster:
            li.setArt({'poster': poster, 'thumb': poster})
    except Exception:
        pass
    xbmc.Player().play(url, li)
    return True


def main():
    path = resolve_path()
    tmdb, imdb, year = provider_ids()
    xbmc.log('[JellyfinSync context] spusteno: id={} tmdb={} imdb={}'.format(
        item_id_from_path(path), tmdb, imdb), xbmc.LOGINFO)
    select_and_play(path, tmdb, imdb, year)


if __name__ == '__main__':
    main()
