"""
Úlohy na pozadí: položky v menu addonu jen zadají požadavek (soubor v profilu),
samotnou práci provádí služba (service.py) a průběh ukazuje nenápadný
DialogProgressBG. Kodi se tak nezablokuje ani při několikaminutovém syncu.

  menu (default.py) ──request_job()──▶ job_request.json ──pop_request()──▶ služba ──JobRunner.run()
                     ◀── job_status.json (průběh / poslední výsledek) ───────────────┘
"""
import json
import os
import threading
import time

import xbmc

from resources.lib.sync_engine import PROFILE, SyncEngine, SyncProgress, _ensure_profile

STATUS_FILE = os.path.join(PROFILE, 'job_status.json')
REQUEST_FILE = os.path.join(PROFILE, 'job_request.json')
SERVICE_FILE = os.path.join(PROFILE, 'service_alive.json')

LABELS = {
    'full': 'Plná synchronizace',
    'incremental': 'Rychlá aktualizace',
    'repair': 'Čištění databáze',
}
BACKUP_DIR = os.path.join(PROFILE, 'backups')
BACKUP_KEEP = 2          # kolik záloh se uchovává
AUTO_BACKUP_MIN_AGE = 12 * 3600   # plný sync zálohuje nejvýš jednou za 12 h
HEARTBEAT_EVERY = 5      # s, jak často služba hlásí, že žije
HEARTBEAT_MAX_AGE = 20   # s, starší hlášení = služba neběží


def _write_json(path, data):
    _ensure_profile()
    tmp = path + '.tmp'
    with open(tmp, 'w') as f:
        json.dump(data, f)
    os.replace(tmp, path)


def _read_json(path):
    try:
        with open(path, 'r') as f:
            return json.load(f)
    except Exception:
        return None


# ----------------------------------------------------------------------
# Strana menu (default.py)
# ----------------------------------------------------------------------

def service_alive(now=None):
    hb = _read_json(SERVICE_FILE)
    return bool(hb) and (now or time.time()) - hb.get('ts', 0) <= HEARTBEAT_MAX_AGE


def read_status():
    return _read_json(STATUS_FILE) or {}


def running_status():
    """Stav běžící úlohy, nebo None (nic neběží / služba mezitím zanikla)."""
    st = read_status()
    if st.get('state') == 'running' and service_alive():
        return st
    return None


def request_job(kind):
    """'queued' | 'busy' | 'no_service'."""
    if kind not in LABELS:
        raise ValueError(kind)
    if not service_alive():
        return 'no_service'
    if running_status() or _read_json(REQUEST_FILE):
        return 'busy'
    _write_json(REQUEST_FILE, {'kind': kind, 'ts': time.time()})
    return 'queued'


# ----------------------------------------------------------------------
# Strana služby (service.py)
# ----------------------------------------------------------------------

def touch_service():
    _write_json(SERVICE_FILE, {'ts': time.time()})


def start_heartbeat(monitor):
    """Vlákno, které každých pár sekund hlásí, že služba žije (i během dlouhého syncu)."""
    def loop():
        while not monitor.abortRequested():
            try:
                touch_service()
            except Exception:
                pass
            if monitor.waitForAbort(HEARTBEAT_EVERY):
                break
    touch_service()
    t = threading.Thread(target=loop, name='jellyfin-sync-heartbeat')
    t.daemon = True
    t.start()
    return t


def pop_request():
    """Vezme čekající požadavek (a smaže ho); vrací kind nebo None."""
    req = _read_json(REQUEST_FILE)
    if req is None:
        return None
    try:
        os.remove(REQUEST_FILE)
    except OSError:
        pass
    kind = req.get('kind')
    return kind if kind in LABELS else None


class JobRunner:
    def __init__(self, monitor, log=None):
        self.monitor = monitor
        self.log = log or (lambda msg: xbmc.log('[JellyfinSync Service] ' + msg, xbmc.LOGINFO))

    # --- pomocné ---
    def _confirm_cleanup(self, n_movies, n_eps, n_shows):
        """Potvrzení smazání: počká, až se přestane přehrávat, a pak se zeptá."""
        import xbmcgui
        player = xbmc.Player()
        waited = 0
        while player.isPlaying() and waited < 900 and not self.monitor.abortRequested():
            if self.monitor.waitForAbort(5):
                return False
            waited += 5
        if self.monitor.abortRequested():
            return False
        return xbmcgui.Dialog().yesno(
            'Jellyfin - Cisteni databaze',
            'Na serveru uz neexistuji (nejdou prehrat):\n'
            '{} filmu, {} epizod, {} serialu.\n'
            'Smazat je a opravit adresy serveru a API klic?'.format(n_movies, n_eps, n_shows))

    def _backup(self, kind, prog, strict=False):
        """
        Záloha Kodi databáze před úlohou, která do ní zapisuje. Čištění (maže) bez zálohy
        neproběhne; u plného syncu se při selhání zálohy jen zaloguje varování.
        """
        from resources.lib.jfcore import maintenance
        from resources.lib.kodidb import find_kodi_db
        db_path = find_kodi_db()
        stem = os.path.splitext(os.path.basename(db_path))[0]
        if kind == 'full':
            age = maintenance.newest_backup_age(BACKUP_DIR, stem)
            if age is not None and age < AUTO_BACKUP_MIN_AGE:
                self.log('Záloha databáze přeskočena (poslední je novější než 12 h).')
                return None
        prog.progress(1, 'Zalohuji databazi...')
        try:
            path = maintenance.backup_database(db_path, BACKUP_DIR, kind, keep=BACKUP_KEEP)
        except Exception as e:
            if kind == 'repair' or strict:
                raise RuntimeError('Zaloha databaze selhala, nic se nemaze: {}'.format(e))
            self.log('VAROVÁNÍ: záloha databáze selhala, pokračuji bez ní: {}'.format(e))
            return None
        self.log('Záloha databáze: {}'.format(path))
        return path

    def run(self, kind):
        """Provede úlohu. Vrací {'ok', 'cancelled', 'summary'}."""
        import xbmcgui
        label = LABELS[kind]
        self.log('Spouštím úlohu: {}'.format(label))
        status = {'state': 'running', 'kind': kind, 'label': label, 'pct': 0,
                  'msg': 'Inicializuji...', 'started': time.time()}
        _write_json(STATUS_FILE, status)
        bg = xbmcgui.DialogProgressBG()
        bg.create(label, 'Inicializuji...')
        last = [0.0]

        def on_progress(pct, msg=''):
            now = time.time()
            if now - last[0] < 1.0 and pct < 100:
                return
            last[0] = now
            status['pct'] = int(pct)
            if msg:
                status['msg'] = msg
            try:
                bg.update(int(pct), label, status['msg'])
                _write_json(STATUS_FILE, status)
            except Exception:
                pass

        prog = SyncProgress(on_progress=on_progress, cancel_check=self.monitor.abortRequested)
        result = {'ok': True, 'cancelled': False, 'summary': ''}
        try:
            engine = SyncEngine(progress=prog)
            if kind in ('full', 'repair'):
                self._backup(kind, prog)
            elif kind == 'incremental':
                # automatický úklid zastaralých záznamů se spustí jen se zálohou databáze
                engine.backup_hook = lambda: self._backup('full', prog, strict=True)
            if kind == 'full':
                engine.full_sync()
            elif kind == 'incremental':
                engine.incremental_sync()
            else:
                stats = engine.repair(confirm=self._confirm_cleanup)
                if stats is None:
                    result.update(cancelled=True, summary='Čištění zrušeno')
                elif stats.get('refused'):
                    result.update(ok=False, summary='Čištění odmítnuto – server vrátil podezřele málo položek, nic se nezměnilo')
                else:
                    result['summary'] = 'Smazáno: {} filmů, {} epizod, {} seriálů; přepsáno adres: {}'.format(
                        stats['movies'], stats['episodes'], stats['shows'], stats.get('rewritten', 0))
            if self.monitor.abortRequested():
                result.update(cancelled=True, summary='Přerušeno ukončením Kodi')
        except Exception as e:
            import traceback
            self.log('CHYBA úlohy {}: {}\n{}'.format(label, e, traceback.format_exc()))
            result.update(ok=False, summary='Chyba: {}'.format(e))
        finally:
            try:
                bg.close()
            except Exception:
                pass

        _write_json(STATUS_FILE, {
            'state': 'idle',
            'last': {'kind': kind, 'label': label, 'ok': result['ok'], 'cancelled': result['cancelled'],
                     'summary': result['summary'], 'finished': time.strftime('%Y-%m-%d %H:%M:%S')}})
        if result['ok'] and not result['cancelled']:
            xbmc.executebuiltin('UpdateLibrary(video)')
        # sync i aktualizace si ohlásí dokončení samy; ostatní případy oznámíme tady
        if kind == 'repair' or not result['ok']:
            if result['summary']:
                xbmcgui.Dialog().notification(
                    'Jellyfin - ' + label, result['summary'],
                    xbmcgui.NOTIFICATION_INFO if result['ok'] else xbmcgui.NOTIFICATION_ERROR, 10000)
        self.log('Úloha dokončena: {} ({})'.format(label, result['summary'] or 'ok'))
        return result
