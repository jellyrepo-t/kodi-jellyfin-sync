"""
Jellyfin klient pro addon – tenký obal nad sdíleným jádrem (resources/lib/jfcore,
které sem při buildu zkopíruje build_addon.py z repozitáře JellyKodiSync).
Zachovává původní rozhraní, aby se zbytek addonu nemusel měnit.
"""
import logging

from resources.lib.jfcore.client import JellyfinClient as _CoreClient
from resources.lib.jfcore.client import JellyfinError  # noqa: F401  (re-export)

API_KEY_APP = "JellyfinKodiSync"


def _addon_version():
    try:
        import xbmcaddon
        return xbmcaddon.Addon().getAddonInfo('version') or '0.0.0'
    except Exception:
        return '0.0.0'


class _KodiLogHandler(logging.Handler):
    """Přepošle logging jádra do kodi.log."""

    def emit(self, record):
        try:
            import xbmc
            level = xbmc.LOGWARNING if record.levelno >= logging.WARNING else xbmc.LOGINFO
            xbmc.log('[JellyfinSync] ' + self.format(record), level)
        except Exception:
            pass


def _install_log_bridge():
    core_log = logging.getLogger('jfcore')
    if not any(isinstance(h, _KodiLogHandler) for h in core_log.handlers):
        core_log.addHandler(_KodiLogHandler())
        core_log.setLevel(logging.INFO)


class JellyfinClient(_CoreClient):
    def __init__(self, server_url, username, password):
        _install_log_bridge()
        super(JellyfinClient, self).__init__(
            server_url, username, password,
            client_name='Kodi', device_name='Kodi',
            device_id='jellyfin-sync-kodi', client_version=_addon_version())

    # původní název nízkoúrovňové metody používá sync_engine.py
    def _request(self, path, method='GET', body=None, timeout=60):
        return self.request(path, method=method, body=body, timeout=timeout)

    def get_or_create_api_key(self):
        """Vrátí platný trvalý API klíč 'JellyfinKodiSync' (uložený/existující/nový)."""
        return self.ensure_api_key(app_name=API_KEY_APP)

    def login(self):
        result = super(JellyfinClient, self).login()
        try:
            info = self.server_info()
            logging.getLogger('jfcore').info('Jellyfin server %s, prihlaseno', info.get('Version', '?'))
        except Exception:
            pass
        return result
