"""
Zápis do Kodi SQLite databáze (MyVideos*.db)
Minimální implementace – název, rok, stream URL, Kodi 21 kompatibilita
"""
import os
import glob
import time
import sqlite3
import xbmc
import xbmcvfs

from resources.lib.jfcore import maintenance as _maint


def find_kodi_db():
    """Najde aktuální MyVideos databázi."""
    try:
        profile = xbmcvfs.translatePath('special://database/')
    except AttributeError:
        profile = xbmc.translatePath('special://database/')
    pattern = os.path.join(profile, 'MyVideos*.db')
    candidates = glob.glob(pattern)
    if not candidates:
        raise IOError('Kodi databáze nenalezena v: ' + profile)
    def db_version(p):
        digits = ''.join(c for c in os.path.basename(p) if c.isdigit())
        return int(digits) if digits else 0
    return max(candidates, key=db_version)


class KodiDB:
    BUSY_TIMEOUT = 30000

    def __init__(self, db_path=None):
        self.db_path = db_path or find_kodi_db()
        self._movie_cols = None
        self._show_cols = None
        self._episode_cols = None

    def _connect(self):
        conn = sqlite3.connect(self.db_path, timeout=30)
        conn.execute('PRAGMA journal_mode=WAL')
        conn.execute('PRAGMA busy_timeout=' + str(self.BUSY_TIMEOUT))
        conn.row_factory = sqlite3.Row
        return conn

    def _execute(self, conn, sql, params=()):
        for attempt in range(5):
            try:
                return conn.execute(sql, params)
            except sqlite3.OperationalError as e:
                if 'locked' in str(e) and attempt < 4:
                    time.sleep(2 ** attempt)
                else:
                    raise

    def _table_columns(self, conn, table):
        rows = conn.execute('PRAGMA table_info(' + table + ')').fetchall()
        return {r['name'] for r in rows}

    def _table_pk(self, conn, table):
        """Vrátí název primárního klíče tabulky."""
        rows = conn.execute('PRAGMA table_info(' + table + ')').fetchall()
        for r in rows:
            if r['pk'] == 1:
                return r['name']
        # Fallback pro starsi Kodi
        fallback = {'movie': 'idMovie', 'tvshow': 'idShow', 'episode': 'idEpisode'}
        return fallback.get(table, 'id')

    def _get_or_create_path(self, conn, path_url, content_type=''):
        row = conn.execute(
            'SELECT idPath FROM path WHERE strPath=?', (path_url,)
        ).fetchone()
        if row:
            # Aktualizuj strContent pokud je prazdny a mame info
            if content_type:
                conn.execute(
                    'UPDATE path SET strContent=? WHERE idPath=? AND (strContent=? OR strContent IS NULL)',
                    (content_type, row[0], '')
                )
            return row[0]
        cur = self._execute(conn,
            'INSERT INTO path (strPath, strContent, strScraper, noUpdate) '
            'VALUES (?, ?, ?, ?)',
            (path_url, content_type, 'metadata.local', 1)
        )
        return cur.lastrowid

    def _get_or_create_file(self, conn, path_id, filename):
        row = conn.execute(
            'SELECT idFile FROM files WHERE idPath=? AND strFilename=?',
            (path_id, filename)
        ).fetchone()
        if row:
            return row[0]
        cur = self._execute(conn,
            'INSERT INTO files (idPath, strFilename, playCount, lastPlayed, dateAdded) '
            'VALUES (?, ?, NULL, NULL, datetime("now"))',
            (path_id, filename)
        )
        return cur.lastrowid

    def _ensure_videoversion(self, conn, movie_id, file_id):
        """Dynamicky INSERT do videoversion podle skutecnych sloupcu tabulky."""
        tbl = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='videoversion'"
        ).fetchone()
        if not tbl:
            return
        exists = conn.execute(
            'SELECT 1 FROM videoversion WHERE idFile=?', (file_id,)
        ).fetchone()
        if exists:
            return
        # Nacteme skutecne sloupce z DB - zadne hadani
        vv_cols = self._table_columns(conn, 'videoversion')
        insert_cols = []
        insert_vals = []
        # idFile je vzdy PK
        insert_cols.append('idFile'); insert_vals.append(file_id)
        # Kodi 21 pouziva idMedia, Kodi 20 pouziva idMovie
        if 'idMedia' in vv_cols:
            insert_cols.append('idMedia'); insert_vals.append(movie_id)
        elif 'idMovie' in vv_cols:
            insert_cols.append('idMovie'); insert_vals.append(movie_id)
        # Typ media - snake_case nebo camelCase
        if 'media_type' in vv_cols:
            insert_cols.append('media_type'); insert_vals.append('movie')
        elif 'mediaType' in vv_cols:
            insert_cols.append('mediaType'); insert_vals.append('movie')
        # itemType
        if 'itemType' in vv_cols:
            insert_cols.append('itemType'); insert_vals.append(0)  # 0=default version, 1=extra
        # idType nebo idVideoVersionType
        if 'idType' in vv_cols:
            insert_cols.append('idType'); insert_vals.append(40400)      # 40400 = Standardní edice
        elif 'idVideoVersionType' in vv_cols:
            insert_cols.append('idVideoVersionType'); insert_vals.append(40400)
        ph = ', '.join(['?'] * len(insert_cols))
        sql = 'INSERT OR IGNORE INTO videoversion (' + ', '.join(insert_cols) + ') VALUES (' + ph + ')'
        self._execute(conn, sql, tuple(insert_vals))

    # ------------------------------------------------------------------
    # Filmy
    # ------------------------------------------------------------------

    def upsert_movie(self, conn, jf_id, title, year, stream_url, overview=''):
        if '/stream' in stream_url:
            idx = stream_url.index('/stream')
            path_url = stream_url[:idx + 1]
            filename = stream_url[idx + 1:]
        else:
            path_url = stream_url
            filename = ''

        # Existuje uz?
        row = conn.execute(
            "SELECT media_id FROM uniqueid "
            "WHERE media_type='movie' AND type='jellyfin' AND value=?",
            (jf_id,)
        ).fetchone()

        if row:
            movie_id = row[0]
            if self._movie_cols is None:
                self._movie_cols = self._table_columns(conn, 'movie')
            pk = self._table_pk(conn, 'movie')
            updates = ['c00=?']
            params = [title]
            if 'c07' in self._movie_cols:
                updates.append('c07=?'); params.append(str(year) if year else '')
            if overview and 'c01' in self._movie_cols:      # popis (Kodi: c01 = plot)
                updates.append('c01=?'); params.append(overview)
            params.append(movie_id)
            self._execute(conn,
                'UPDATE movie SET ' + ', '.join(updates) + ' WHERE ' + pk + '=?',
                tuple(params)
            )
            return movie_id

        # Novy film
        path_id = self._get_or_create_path(conn, path_url, content_type='movies')
        file_id = self._get_or_create_file(conn, path_id, filename)

        # Zjisti sloupce
        if self._movie_cols is None:
            self._movie_cols = self._table_columns(conn, 'movie')

        cols = ['idFile', 'c00']
        vals = [file_id, title]

        if overview and 'c01' in self._movie_cols:
            cols.append('c01'); vals.append(overview)
        if 'c07' in self._movie_cols:
            cols.append('c07'); vals.append(str(year) if year else '')
        if 'c12' in self._movie_cols:
            cols.append('c12'); vals.append(str(year) if year else '')
        if 'premiered' in self._movie_cols:
            cols.append('premiered')
            vals.append('{}-01-01'.format(year) if year else '')

        placeholders = ', '.join(['?'] * len(cols))
        sql = 'INSERT INTO movie (' + ', '.join(cols) + ') VALUES (' + placeholders + ')'
        cur = self._execute(conn, sql, tuple(vals))
        movie_id = cur.lastrowid

        self._execute(conn,
            "INSERT OR IGNORE INTO uniqueid (media_id, media_type, type, value) "
            "VALUES (?, 'movie', 'jellyfin', ?)",
            (movie_id, jf_id)
        )
        self._ensure_videoversion(conn, movie_id, file_id)
        return movie_id

    # ------------------------------------------------------------------
    # Seriály
    # ------------------------------------------------------------------

    def upsert_show(self, conn, jf_id, title, year, overview=''):
        row = conn.execute(
            "SELECT media_id FROM uniqueid "
            "WHERE media_type='tvshow' AND type='jellyfin' AND value=?",
            (jf_id,)
        ).fetchone()
        if self._show_cols is None:
            self._show_cols = self._table_columns(conn, 'tvshow')

        if row:
            show_id = row[0]
            pk = self._table_pk(conn, 'tvshow')
            sets, args = ['c00=?'], [title]
            if overview and 'c01' in self._show_cols:
                sets.append('c01=?'); args.append(overview)
            args.append(show_id)
            self._execute(conn,
                'UPDATE tvshow SET ' + ', '.join(sets) + ' WHERE ' + pk + '=?',
                tuple(args)
            )
            return show_id

        cols = ['c00']
        vals = [title]
        if overview and 'c01' in self._show_cols:
            cols.append('c01'); vals.append(overview)
        if 'c05' in self._show_cols:
            cols.append('c05'); vals.append(str(year) if year else '')

        # idParentPath – jen pokud existuje
        if 'idParentPath' in self._show_cols:
            cols.append('idParentPath'); vals.append(None)

        placeholders = ', '.join(['?'] * len(cols))
        sql = 'INSERT INTO tvshow (' + ', '.join(cols) + ') VALUES (' + placeholders + ')'
        cur = self._execute(conn, sql, tuple(vals))
        show_id = cur.lastrowid

        self._execute(conn,
            "INSERT OR IGNORE INTO uniqueid (media_id, media_type, type, value) "
            "VALUES (?, 'tvshow', 'jellyfin', ?)",
            (show_id, jf_id)
        )
        return show_id

    def upsert_provider_ids(self, conn, media_id, media_type, provider_ids):
        """Zapíše TMDB/TVDB/IMDB ID do uniqueid tabulky pro rozpoznání v Kodi skinech."""
        if not provider_ids:
            return
        # Mapování Jellyfin názvů na Kodi typy
        mapping = {
            'Tmdb': 'tmdb',
            'Tvdb': 'tvdb',
            'Imdb': 'imdb',
            'TmdbCollection': 'tmdbSet',
        }
        for jf_key, kodi_type in mapping.items():
            value = provider_ids.get(jf_key)
            if not value:
                continue
            # Zkontroluj jestli uz existuje
            exists = conn.execute(
                "SELECT 1 FROM uniqueid WHERE media_id=? AND media_type=? AND type=?",
                (media_id, media_type, kodi_type)
            ).fetchone()
            if not exists:
                self._execute(conn,
                    "INSERT OR IGNORE INTO uniqueid (media_id, media_type, type, value) "
                    "VALUES (?, ?, ?, ?)",
                    (media_id, media_type, kodi_type, str(value))
                )
        self._set_default_uniqueid(conn, media_id, media_type)

    # Kodi bere „imdbnumber“ z výchozího uniqueid: movie.c09 / tvshow.c12 = uniqueid_id.
    # Filmy: IMDb, seriály: TVDB (jako dřív u Kodi/Trakt doplňku), jinak další dostupné.
    DEFAULT_UID_COLUMN = {'movie': 'c09', 'tvshow': 'c12'}
    DEFAULT_UID_ORDER = {'movie': ('imdb', 'tmdb', 'tvdb'), 'tvshow': ('tvdb', 'imdb', 'tmdb')}

    def _set_default_uniqueid(self, conn, media_id, media_type):
        col = self.DEFAULT_UID_COLUMN.get(media_type)
        if not col:
            return
        table = media_type
        if col not in self._table_columns(conn, table):
            return
        ids = {r[0]: r[1] for r in conn.execute(
            "SELECT type, uniqueid_id FROM uniqueid WHERE media_id=? AND media_type=?",
            (media_id, media_type))}
        wanted = next((ids[t] for t in self.DEFAULT_UID_ORDER[media_type] if t in ids), None)
        if wanted is None:
            return
        pk = self._table_pk(conn, table)
        current = conn.execute(
            'SELECT ' + col + ' FROM ' + table + ' WHERE ' + pk + '=?', (media_id,)).fetchone()
        if current is not None and str(current[0]) != str(wanted):
            self._execute(conn, 'UPDATE ' + table + ' SET ' + col + '=? WHERE ' + pk + '=?',
                          (str(wanted), media_id))

    def link_show_path(self, conn, show_id, show_path_url):
        path_id = self._get_or_create_path(conn, show_path_url, content_type='tvshows')
        exists = conn.execute(
            'SELECT 1 FROM tvshowlinkpath WHERE idShow=? AND idPath=?',
            (show_id, path_id)
        ).fetchone()
        if not exists:
            self._execute(conn,
                'INSERT INTO tvshowlinkpath (idShow, idPath) VALUES (?, ?)',
                (show_id, path_id)
            )

    # ------------------------------------------------------------------
    # Epizody
    # ------------------------------------------------------------------

    def _get_or_create_season(self, conn, show_id, season_num):
        """Vrátí idSeason pro daný seriál a číslo sezóny, vytvoří pokud neexistuje."""
        season_num = season_num if season_num is not None else 0
        row = conn.execute(
            'SELECT idSeason FROM seasons WHERE idShow=? AND season=?',
            (show_id, season_num)
        ).fetchone()
        if row:
            return row[0]
        # Zkontroluj jestli tabulka seasons existuje
        tbl = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='seasons'"
        ).fetchone()
        if not tbl:
            return None
        cur = self._execute(conn,
            'INSERT INTO seasons (idShow, season) VALUES (?, ?)',
            (show_id, season_num)
        )
        return cur.lastrowid

    def upsert_episode(self, conn, jf_id, show_id, title, season, episode, year, stream_url,
                       overview=''):
        if '/stream' in stream_url:
            idx = stream_url.index('/stream')
            path_url = stream_url[:idx + 1]
            filename = stream_url[idx + 1:]
        else:
            path_url = stream_url
            filename = ''

        row = conn.execute(
            "SELECT media_id FROM uniqueid "
            "WHERE media_type='episode' AND type='jellyfin' AND value=?",
            (jf_id,)
        ).fetchone()

        if self._episode_cols is None:
            self._episode_cols = self._table_columns(conn, 'episode')

        if row:
            ep_id = row[0]
            pk = self._table_pk(conn, 'episode')
            # Kromě názvu opravíme i číslo sezóny/dílu a vazbu na sezónu – starší verze
            # doplňku je uložily špatně (prohozené) a Kodi pak zobrazovalo jen část dílů.
            sets, args = ['c00=?'], [title]
            if overview and 'c01' in self._episode_cols:
                sets.append('c01=?'); args.append(overview)
            if 'c12' in self._episode_cols:
                sets.append('c12=?'); args.append(str(season) if season is not None else '')
            if 'c13' in self._episode_cols:
                sets.append('c13=?'); args.append(str(episode) if episode is not None else '')
            if 'idSeason' in self._episode_cols:
                season_id = self._get_or_create_season(conn, show_id, season)
                if season_id is not None:
                    sets.append('idSeason=?'); args.append(season_id)
            args.append(ep_id)
            self._execute(conn,
                'UPDATE episode SET ' + ', '.join(sets) + ' WHERE ' + pk + '=?',
                tuple(args)
            )
            return ep_id

        path_id = self._get_or_create_path(conn, path_url)
        file_id = self._get_or_create_file(conn, path_id, filename)

        # Kodi 21: episode vyzaduje idSeason - ziskej nebo vytvor zaznam v seasons
        season_id = None
        if 'idSeason' in self._episode_cols:
            season_id = self._get_or_create_season(conn, show_id, season)

        cols = ['idFile', 'idShow', 'c00']
        vals = [file_id, show_id, title]
        if overview and 'c01' in self._episode_cols:
            cols.append('c01'); vals.append(overview)

        if 'idSeason' in self._episode_cols and season_id is not None:
            cols.append('idSeason'); vals.append(season_id)
        # Kodi konvence: c12=sezona, c13=cislo epizody
        if 'c12' in self._episode_cols:
            cols.append('c12'); vals.append(str(season) if season is not None else '')
        if 'c13' in self._episode_cols:
            cols.append('c13'); vals.append(str(episode) if episode is not None else '')
        if 'c05' in self._episode_cols:
            cols.append('c05'); vals.append('{}-01-01'.format(year) if year else '')

        placeholders = ', '.join(['?'] * len(cols))
        sql = 'INSERT INTO episode (' + ', '.join(cols) + ') VALUES (' + placeholders + ')'
        cur = self._execute(conn, sql, tuple(vals))
        ep_id = cur.lastrowid

        self._execute(conn,
            "INSERT OR IGNORE INTO uniqueid (media_id, media_type, type, value) "
            "VALUES (?, 'episode', 'jellyfin', ?)",
            (ep_id, jf_id)
        )
        return ep_id

    # ------------------------------------------------------------------
    # Čištění + statistiky
    # ------------------------------------------------------------------

    def delete_movie(self, conn, jf_id):
        row = conn.execute(
            "SELECT media_id FROM uniqueid "
            "WHERE media_type='movie' AND type='jellyfin' AND value=?",
            (jf_id,)
        ).fetchone()
        if not row:
            return
        movie_id = row[0]
        pk = self._table_pk(conn, 'movie')
        conn.execute('DELETE FROM movie WHERE ' + pk + '=?', (movie_id,))
        conn.execute(
            "DELETE FROM uniqueid WHERE media_id=? AND media_type='movie'",
            (movie_id,)
        )

    # ------------------------------------------------------------------
    # Údržba: mrtvé záznamy + adresy/API klíč (logika je ve sdíleném jfcore.maintenance)
    # ------------------------------------------------------------------

    def find_dead(self, conn, alive_movies, alive_episodes):
        return _maint.find_dead(conn, alive_movies, alive_episodes)

    def find_dead_with_totals(self, conn, alive_movies, alive_episodes):
        return _maint.find_dead_with_totals(conn, alive_movies, alive_episodes)

    def is_suspicious(self, total, dead):
        return _maint.is_suspicious(total, dead)

    def count_dead_shows(self, conn, dead_episodes, alive_series):
        return _maint.count_dead_shows(conn, dead_episodes, alive_series)

    def delete_dead(self, conn, dead_movies, dead_episodes, alive_series, progress=None, alive_movies=None):
        return _maint.delete_dead(conn, dead_movies, dead_episodes, alive_series, progress,
                                  alive_movies=alive_movies)

    def count_version_repairs(self, conn, alive_movies):
        return sum(len(r[3]) for r in _maint.plan_version_repairs(conn, alive_movies))

    def fix_default_version_type(self, conn):
        """
        Starší verze doplňku zapisovala všem filmům typ verze 40401 („Rozšířená edice“) místo
        40400 („Standardní edice“). Opraví se jen když ho mají VŠECHNY filmy (jistě chyba,
        ne ruční volba uživatele). Vrací počet změněných řádků.
        """
        try:
            total, ext = conn.execute(
                "SELECT COUNT(*), SUM(idType=40401) FROM videoversion WHERE media_type='movie'").fetchone()
        except Exception:
            return 0
        if not total or ext != total:
            return 0
        return conn.execute(
            "UPDATE videoversion SET idType=40400 WHERE media_type='movie' AND idType=40401").rowcount

    def rewrite_urls(self, conn, server, api_key, progress=None):
        return _maint.rewrite_urls(conn, server, api_key, progress)

    def count_jellyfin(self, conn):
        """Kolik záznamů v Kodi pochází z Jellyfinu (mají uniqueid typu jellyfin)."""
        def n(media_type):
            return conn.execute(
                "SELECT COUNT(*) FROM uniqueid WHERE media_type=? AND type='jellyfin'",
                (media_type,)).fetchone()[0]
        return {'movies': n('movie'), 'shows': n('tvshow'), 'episodes': n('episode')}

    def get_stats(self, conn):
        movies = conn.execute('SELECT COUNT(*) FROM movie').fetchone()[0]
        shows = conn.execute('SELECT COUNT(*) FROM tvshow').fetchone()[0]
        episodes = conn.execute('SELECT COUNT(*) FROM episode').fetchone()[0]
        return {'movies': movies, 'shows': shows, 'episodes': episodes}

    def log_schema(self, conn):
        """Zaloguje skutečné PK tabulek pro diagnostiku."""
        import xbmc
        for table in ('movie', 'tvshow', 'episode', 'uniqueid'):
            try:
                pk = self._table_pk(conn, table)
                cols = self._table_columns(conn, table)
                xbmc.log('[JellyfinSync] Schema {}: PK={}, cols={}'.format(
                    table, pk, sorted(cols)), xbmc.LOGINFO)
            except Exception as e:
                xbmc.log('[JellyfinSync] Schema {} error: {}'.format(table, e), xbmc.LOGWARNING)
