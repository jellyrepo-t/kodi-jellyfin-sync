"""
Maskování tajných hodnot v textu určeném do logu.

Stream a náhledové adresy nesou API klíč v dotazu (`...?api_key=XYZ`) a výjimky z knihoven
(requests, urllib) do textu chyby vkládají celou adresu. Bez maskování by se klíč s plným
přístupem k serveru dostal do logů – a ty leží vedle projektu (OneDrive) a lidé je posílají
při hlášení chyb.
"""
import logging
import re

MASK = "***"

_PATTERNS = (
    # ?api_key=XYZ, &ApiKey=XYZ, password=XYZ, client_secret=XYZ ...
    (re.compile(r"(?i)\b(api_?key|access_?token|refresh_?token|password|pw|client_secret|token)=([^&\s\"'<>]+)"),
     r"\1=" + MASK),
    # Authorization: MediaBrowser ..., Token="XYZ"
    (re.compile(r'(?i)\b(Token)="[^"]*"'), r'\1="' + MASK + '"'),
    (re.compile(r"(?i)\b(Bearer)\s+[A-Za-z0-9._~+/=-]+"), r"\1 " + MASK),
    # JSON: "AccessToken": "XYZ", "Pw": "XYZ"
    (re.compile(r'(?i)("(?:AccessToken|access_token|refresh_token|Pw|Password|api_key|client_secret)"\s*:\s*)"[^"]*"'),
     r'\1"' + MASK + '"'),
)


def redact(text):
    """Text bez tajných hodnot (nestringové hodnoty vrací beze změny)."""
    if not isinstance(text, str) or not text:
        return text
    for pattern, repl in _PATTERNS:
        text = pattern.sub(repl, text)
    return text


class RedactingFilter(logging.Filter):
    """Filtr pro handler: zprávu zformátuje, zamaskuje a uloží zpět do záznamu."""

    def filter(self, record):
        try:
            message = record.getMessage()
        except Exception:
            return True
        clean = redact(message)
        if clean != message:
            record.msg, record.args = clean, None
        if record.exc_info and not record.exc_text:
            record.exc_text = logging.Formatter().formatException(record.exc_info)
        if record.exc_text:
            record.exc_text = redact(record.exc_text)
        return True
