"""
Hlášení přehrávání Jellyfinu.

Kodi přehrává přímou adresu `.../Videos/<id>/stream?static=true&api_key=...`, takže Jellyfin sám neví, že se
něco přehrává: v řídicím panelu není "Právě se přehrává" a nepřenáší se pozice pro pokračování ani stav
shlédnuto. Tenhle modul to hlásí serveru stejně jako oficiální klienty:

    POST /Sessions/Playing            začátek
    POST /Sessions/Playing/Progress   průběh (pauza, pokračování, přetočení, každých pár sekund)
    POST /Sessions/Playing/Stopped    konec (podle pozice server uloží pokračování nebo označí jako shlédnuté)

Přehrávač se dotazuje (poll) ze samostatného vlákna místo callbacků xbmc.Player: ty se doručují, jen když
služba čeká v waitForAbort, takže by je několikaminutová synchronizace zadržela.

Modul nepoužívá xbmc – logika (Tracker, Reporter) jde testovat na falešném serveru.
"""
import logging
import re
import time
import uuid

log = logging.getLogger('jfcore')

STREAM_RE = re.compile(r'/Videos/([0-9a-f]{32})/stream')
TICKS = 10000000          # Jellyfin měří čas v desetinách mikrosekundy
PROGRESS_EVERY = 10.0     # s, jak často se hlásí průběh
SEEK_JUMP = 5.0           # s, o kolik se musí pozice lišit od očekávané, aby se brala jako přetočení
END_TOLERANCE = 3.0       # s, zastavení takhle blízko konci se hlásí jako dohrané
RETRY_AFTER = 60.0        # s, po selhání se hlášení chvíli neopakuje (server není dostupný)
POST_TIMEOUT = 5


def item_id_from_url(url):
    """Id položky z adresy streamu Jellyfinu (jiné adresy, např. z jiného doplňku, vrací None)."""
    match = STREAM_RE.search(url or '')
    return match.group(1) if match else None


def read_state(player, is_paused):
    """
    Stav přehrávače pro Tracker.poll(), nebo None, když se nepřehrává video. `player` je xbmc.Player,
    `is_paused` je funkce vracející True při pauze (xbmc.getCondVisibility('Player.Paused')).
    """
    try:
        if not player.isPlayingVideo():
            return None
        return {'file': player.getPlayingFile(), 'position': float(player.getTime()),
                'duration': float(player.getTotalTime()), 'paused': bool(is_paused())}
    except RuntimeError:                      # přehrávání mezitím skončilo
        return None


class Reporter(object):
    """Posílá serveru hlášení. Chyba sítě nikdy nevyhodí výjimku a nezpomalí přehrávání."""

    def __init__(self, make_client, clock=time.time):
        self._make_client = make_client       # () -> přihlášený klient (vyhodí výjimku, když to nejde)
        self._clock = clock
        self._client = None
        self._down_until = 0.0

    def _post(self, path, body, force=False):
        now = self._clock()
        if not force and now < self._down_until:
            return False
        for attempt in (1, 2):
            try:
                if self._client is None:
                    self._client = self._make_client()
                self._client.request(path, method='POST', body=body, timeout=POST_TIMEOUT)
                return True
            except Exception as e:
                self._client = None
                if getattr(e, 'status', None) == 401 and attempt == 1:
                    continue                  # token přestal platit (odhlášení na serveru) – přihlásit znovu
                log.warning('Hlaseni prehravani selhalo: %s', e)
                self._down_until = now + RETRY_AFTER
                return False
        return False

    @staticmethod
    def _body(session, position, paused):
        return {'ItemId': session['item_id'], 'MediaSourceId': session['item_id'],
                'PlaySessionId': session['play_session_id'], 'PositionTicks': int(max(position, 0) * TICKS),
                'CanSeek': True, 'IsPaused': bool(paused), 'IsMuted': False, 'PlayMethod': 'DirectPlay'}

    def start(self, session, position, paused):
        return self._post('/Sessions/Playing', self._body(session, position, paused))

    def progress(self, session, position, paused, event):
        body = self._body(session, position, paused)
        body['EventName'] = event
        return self._post('/Sessions/Playing/Progress', body)

    def stop(self, session, position):
        body = self._body(session, position, False)
        body['Failed'] = False
        return self._post('/Sessions/Playing/Stopped', body, force=True)


class Tracker(object):
    """Z opakovaných stavů přehrávače pozná začátek, pauzu, přetočení a konec a zavolá Reporter."""

    def __init__(self, reporter, clock=time.time):
        self.reporter = reporter
        self._clock = clock
        self.current = None

    def poll(self, state, enabled=True):
        item = item_id_from_url(state['file']) if (state and enabled) else None
        cur = self.current
        if cur is not None and item != cur['item_id']:
            self._finish()                    # konec přehrávání nebo přepnutí na jinou položku
            cur = None
        if item is None:
            return
        now = self._clock()
        position, paused = state['position'], state['paused']
        if cur is None:
            self.current = {'item_id': item, 'play_session_id': uuid.uuid4().hex, 'position': position,
                            'duration': state.get('duration') or 0.0, 'paused': paused,
                            'sent_at': now, 'sent_position': position}
            self.reporter.start(self.current, position, paused)
            return
        cur['duration'] = state.get('duration') or cur['duration']
        expected = cur['sent_position'] + (0.0 if cur['paused'] else now - cur['sent_at'])
        cur['position'] = position
        if paused != cur['paused']:
            event = 'Pause' if paused else 'Unpause'
        elif abs(position - expected) > SEEK_JUMP:
            event = 'TimeUpdate'              # přetočení
        elif now - cur['sent_at'] >= PROGRESS_EVERY:
            event = 'TimeUpdate'
        else:
            return
        cur['paused'] = paused
        cur['sent_at'], cur['sent_position'] = now, position
        self.reporter.progress(cur, position, paused, event)

    def _finish(self):
        cur, self.current = self.current, None
        position = cur['position']
        if cur['duration'] and cur['duration'] - position <= END_TOLERANCE:
            position = cur['duration']        # dohráno do konce (poslední dotaz mohl být o pár sekund dřív)
        self.reporter.stop(cur, position)
