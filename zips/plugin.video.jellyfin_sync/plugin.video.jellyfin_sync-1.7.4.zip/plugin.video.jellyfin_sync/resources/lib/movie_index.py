"""
Rejstřík filmů a seriálů na Jellyfinu podle TMDb / IMDb ID.

Jellyfin neumí najít položku podle ID z TMDb (parametr AnyProviderIdEquals ignoruje), proto si
addon drží vlastní malý rejstřík {"movie:tmdb:603": [id položky, ...], "series:tmdb:1396": [...]}.
Plná synchronizace ho zapíše z dat, která stejně stahuje; kde synchronizace neběží (např. PC,
kde knihovnu plní PC appka), se stáhne lehkými dotazy a platí den.
"""
import json
import os
import time

from resources.lib.sync_engine import PROFILE, _ensure_profile

INDEX_FILE = os.path.join(PROFILE, 'movie_index.json')
FORMAT = 2
MAX_AGE = 24 * 3600            # s, pak se rejstřík obnoví
RETRY_AGE = 10 * 60            # s, nenalezená položka -> obnovit rejstřík, pokud je starší (nové filmy)
KINDS = {'movie': 'Movie', 'series': 'Series'}


def build_from_items(items, kind='movie', index=None):
    index = {} if index is None else index
    for it in items:
        ids = it.get('ProviderIds') or {}
        for provider in ('Tmdb', 'Imdb', 'Tvdb'):
            value = ids.get(provider)
            if value:
                key = '{}:{}:{}'.format(kind, provider.lower(), value)
                if it['Id'] not in index.setdefault(key, []):
                    index[key].append(it['Id'])
    return index


def save(index, now=None):
    _ensure_profile()
    tmp = INDEX_FILE + '.tmp'
    with open(tmp, 'w') as f:
        json.dump({'v': FORMAT, 'ts': now or time.time(), 'index': index}, f)
    os.replace(tmp, INDEX_FILE)


def load():
    try:
        with open(INDEX_FILE, 'r') as f:
            data = json.load(f)
        if data.get('v') != FORMAT:
            return 0, None
        return data.get('ts', 0), data.get('index', {})
    except Exception:
        return 0, None


def refresh(jf):
    index = {}
    for kind, item_type in KINDS.items():
        build_from_items(jf.get_items(item_type, fields='ProviderIds'), kind, index)
    save(index)
    return index


def lookup(jf, tmdb=None, imdb=None, kind='movie', tvdb=None, now=None):
    """ID položek Jellyfinu (filmů nebo seriálů) se zadaným ID. Prázdný seznam = na serveru není."""
    now = now or time.time()
    keys = ['{}:{}:{}'.format(kind, p, v) for p, v in (('tmdb', tmdb), ('imdb', imdb), ('tvdb', tvdb)) if v]
    if not keys:
        return []
    ts, index = load()
    if index is None or now - ts > MAX_AGE:
        index, ts = refresh(jf), now

    def find(idx):
        out = []
        for k in keys:
            for item_id in idx.get(k, []):
                if item_id not in out:
                    out.append(item_id)
        return out

    found = find(index)
    if not found and now - ts > RETRY_AGE:          # položka mohla na server přibýt od poslední obnovy
        found = find(refresh(jf))
    return found
