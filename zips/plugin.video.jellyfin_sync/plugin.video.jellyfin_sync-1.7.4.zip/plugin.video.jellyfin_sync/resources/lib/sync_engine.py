"""
Synchronizační engine – řídí celý proces Jellyfin → Kodi DB
"""
import json
import os
import time
import xbmc
import xbmcaddon
import xbmcvfs

from resources.lib.jellyfin import JellyfinClient, JellyfinError
from resources.lib.kodidb import KodiDB
from resources.lib.jfcore import versions as versions_mod

ADDON = xbmcaddon.Addon()

# Kodi 19+ přesunulo translatePath do xbmcvfs
try:
    PROFILE = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.jellyfin_sync/')
except AttributeError:
    PROFILE = xbmc.translatePath('special://profile/addon_data/plugin.video.jellyfin_sync/')

STATE_FILE = os.path.join(PROFILE, 'sync_state.json')


def _ensure_profile():
    if not xbmcvfs.exists(PROFILE):
        xbmcvfs.mkdirs(PROFILE)


def load_state():
    _ensure_profile()
    if os.path.exists(STATE_FILE):
        try:
            with open(STATE_FILE, 'r') as f:
                return json.load(f)
        except Exception:
            pass
    return {}


def save_state(state):
    _ensure_profile()
    with open(STATE_FILE, 'w') as f:
        json.dump(state, f, indent=2)


class SyncProgress:
    """Jednoduchý callback pro průběh – předává zprávy do GUI."""
    def __init__(self, on_message=None, on_progress=None, cancel_check=None):
        self._on_message = on_message or (lambda msg: None)
        self._on_progress = on_progress or (lambda pct, msg: None)
        self._cancel_check = cancel_check   # např. monitor.abortRequested (ukončení Kodi)
        self.cancelled = False

    def message(self, msg):
        xbmc.log('[JellyfinSync] ' + msg, xbmc.LOGINFO)
        self._on_message(msg)

    def progress(self, pct, msg=''):
        self._on_progress(pct, msg)

    def check_cancel(self):
        if self.cancelled:
            return True
        return bool(self._cancel_check and self._cancel_check())

    def notify(self, new_movies, new_episodes, sync_type='full'):
        try:
            import xbmcgui
            if sync_type == 'incremental':
                if new_movies == 0 and new_episodes == 0:
                    msg = 'Žádné změny'
                else:
                    parts = []
                    if new_movies > 0:
                        parts.append('+{} {}'.format(new_movies, 'film' if new_movies == 1 else 'filmů' if new_movies < 5 else 'filmů'))
                    if new_episodes > 0:
                        parts.append('+{} {}'.format(new_episodes, 'epizoda' if new_episodes == 1 else 'epizody' if new_episodes < 5 else 'epizod'))
                    msg = ', '.join(parts)
                title = 'Jellyfin – Aktualizace dokončena'
            else:
                parts = []
                if new_movies > 0:
                    parts.append('{} {}'.format(new_movies, 'film' if new_movies == 1 else 'filmy' if new_movies < 5 else 'filmů'))
                if new_episodes > 0:
                    parts.append('{} {}'.format(new_episodes, 'epizoda' if new_episodes == 1 else 'epizody' if new_episodes < 5 else 'epizod'))
                msg = ', '.join(parts) if parts else 'Hotovo'
                title = 'Jellyfin – Sync dokončen'
            xbmcgui.Dialog().notification(
                title, msg,
                xbmcgui.NOTIFICATION_INFO, 6000
            )
        except Exception as e:
            import xbmc
            xbmc.log('[JellyfinSync] Notify error: ' + str(e), xbmc.LOGWARNING)


class BatchWriter:
    """
    Dávkové zápisy: jedna transakce na `size` položek místo commitu (a fsync na disk) po každé.
    Každá položka běží ve vlastním SAVEPOINTu, takže chyba jedné položky vrátí jen ji
    a ostatní zůstanou. Použití:

        batch = BatchWriter(conn)
        for item in items:
            try:
                with batch.item():
                    ... zápisy ...
            except Exception: ...
        batch.flush()          # vždy na konci (i po break/cancel)
    """
    def __init__(self, conn, size=500):
        self.conn = conn
        self.size = size
        self._n = 0

    def item(self):
        from contextlib import contextmanager

        @contextmanager
        def ctx():
            conn = self.conn
            if not conn.in_transaction:
                conn.execute('BEGIN')
            conn.execute('SAVEPOINT item')
            try:
                yield
            except BaseException:
                conn.execute('ROLLBACK TO item')
                conn.execute('RELEASE item')
                raise
            conn.execute('RELEASE item')
            self._n += 1
            if self._n % self.size == 0:
                conn.commit()
        return ctx()

    def flush(self):
        if self.conn.in_transaction:
            self.conn.commit()


def _upsert_art(conn, media_id, media_type, art_type, url):
    """Jeden řádek na (media_id, media_type, type) – tabulka art nemá unikátní index, takže
    INSERT OR REPLACE by při každé synchronizaci přidal další duplicitní řádek."""
    row = conn.execute("SELECT art_id, url FROM art WHERE media_id=? AND media_type=? AND type=? "
                       "ORDER BY art_id LIMIT 1", (media_id, media_type, art_type)).fetchone()
    if row:
        if row[1] != url:
            conn.execute("UPDATE art SET url=? WHERE art_id=?", (url, row[0]))
        return 1
    conn.execute("INSERT INTO art (media_id, media_type, type, url) VALUES (?, ?, ?, ?)",
                 (media_id, media_type, art_type, url))
    return 1


def dedupe_art(conn):
    """Odstraní duplicitní náhledy po starších verzích (INSERT OR REPLACE). Vrací počet smazaných."""
    return conn.execute("DELETE FROM art WHERE art_id NOT IN "
                        "(SELECT MIN(art_id) FROM art GROUP BY media_id, media_type, type)").rowcount


def _sync_art(conn, jf, db, items, media_type, progress):
    """Zapíše URL náhledů (poster, fanart) do tabulky art."""
    server = jf.server
    api_key = jf.api_key
    ok = 0
    total = len(items)
    for i, item in enumerate(items):
        if i % 200 == 0:
            progress.progress(
                (39 if media_type == 'movie' else 49),
                'Náhledy {} {}/{}'.format(media_type, i, total)
            )
        item_id = item['Id']
        # Zjisti media_id z DB
        row = conn.execute(
            "SELECT media_id FROM uniqueid WHERE media_type=? AND type='jellyfin' AND value=?",
            (media_type, item_id)
        ).fetchone()
        if not row:
            continue
        media_id = row[0]

        # Poster (Primary image)
        poster_url = '{}/Items/{}/Images/Primary?api_key={}'.format(server, item_id, api_key)
        thumb_url = '{}/Items/{}/Images/Thumb?api_key={}'.format(server, item_id, api_key)
        fanart_url = '{}/Items/{}/Images/Backdrop?api_key={}'.format(server, item_id, api_key)
        logo_url = '{}/Items/{}/Images/Logo?api_key={}'.format(server, item_id, api_key)

        # Jellyfin říká, které obrázky položka má (ImageTags / BackdropImageTags); bez té informace
        # (starší data) se zapíše vše jako dřív. Neexistující obrázky by v Kodi končily chybou 404.
        tags = item.get('ImageTags')
        known = tags is not None or 'BackdropImageTags' in item
        tags = tags or {}
        art_items = [
            ('poster', poster_url, 'Primary' in tags),
            ('thumb', thumb_url, 'Thumb' in tags),
            ('fanart', fanart_url, bool(item.get('BackdropImageTags'))),
            ('clearlogo', logo_url, 'Logo' in tags),
        ]
        for art_type, url, exists in art_items:
            try:
                if exists or not known:
                    ok += _upsert_art(conn, media_id, media_type, art_type, url)
                else:
                    conn.execute(
                        "DELETE FROM art WHERE media_id=? AND media_type=? AND type=? AND url LIKE ?",
                        (media_id, media_type, art_type, '%/Items/{}/Images/%'.format(item_id)))
            except Exception:
                pass
    try:
        conn.commit()
    except Exception:
        pass
    import xbmc
    xbmc.log('[JellyfinSync] Art zapsano: {} pro {} {}'.format(ok, total, media_type), xbmc.LOGINFO)


class SyncEngine:
    def __init__(self, progress=None):
        self.progress = progress or SyncProgress()
        self.state = load_state()
        self._jf = None
        self._db = None
        # Zavolá se těsně před automatickým mazáním při rychlé aktualizaci (záloha databáze).
        # Bez hooku se při rychlé aktualizaci nikdy nemaže.
        self.backup_hook = None

    # ------------------------------------------------------------------
    # Připojení
    # ------------------------------------------------------------------

    def _connect(self):
        addon = xbmcaddon.Addon()
        server = addon.getSetting('server_url').rstrip('/')
        username = addon.getSetting('username')
        password = addon.getSetting('password')

        if not server or not username:
            raise JellyfinError('Chybí nastavení serveru nebo přihlašovací údaje')

        self._jf = JellyfinClient(server, username, password)

        # Pokud mame ulozeny API klic, overime ho - vyhneme se nutnosti loginu
        saved_key = self.state.get('api_key')
        saved_user_id = self.state.get('user_id')

        if saved_key and saved_user_id:
            self.progress.message('Ověřuji uložený API klíč...')
            self._jf.api_key = saved_key
            self._jf.token = saved_key
            self._jf.user_id = saved_user_id
            try:
                self._jf._request('/Users/{}'.format(saved_user_id), timeout=10)
                self.progress.message('Připojeno přes uložený API klíč.')
            except JellyfinError:
                self.progress.message('API klíč expiroval, přihlašuji znovu...')
                self._jf.token = None
                self._jf.api_key = None
                self._do_login()
        else:
            self.progress.message('Přihlašování k Jellyfin...')
            self._do_login()

        self._db = KodiDB()
        self.progress.message('Připojeno k Kodi databázi: ' + os.path.basename(self._db.db_path))

    def _do_login(self):
        self._jf.login()
        key = self._jf.get_or_create_api_key()
        self.state['api_key'] = key
        self.state['user_id'] = self._jf.user_id
        save_state(self.state)

    # ------------------------------------------------------------------
    # Výběr knihoven
    # ------------------------------------------------------------------

    def get_available_libraries(self):
        """Vrátí seznam knihoven ze serveru (pro nastavení)."""
        self._connect()
        return self._jf.get_libraries()

    def _selected_library_ids(self, media_type):
        """Vrátí seznam ID vybraných knihoven pro daný typ (movie/tvshow)."""
        key = 'libraries_{}'.format(media_type)
        ids = self.state.get(key, [])
        return ids if ids else None

    # ------------------------------------------------------------------
    # Údržba knihovny: mrtvé záznamy + adresy serveru / API klíč
    # ------------------------------------------------------------------

    def _fetch_ids(self, item_type):
        """Množina Jellyfin ID všech položek daného typu (bez filtru knihoven). U filmů včetně
        alternativních verzí sloučených položek."""
        if item_type == 'Movie':
            return self._jf.get_alive_movie_ids()
        return set(i['Id'] for i in self._jf.get_items(item_type, fields=''))

    def _cleanup(self, conn, alive_movies, alive_episodes, alive_series, confirm=None,
                 before_delete=None):
        """
        Smaže záznamy, jejichž ID už na serveru není, a přepíše adresu/API klíč
        u zbylých. Prázdný seznam ze serveru typ NEMAŽE (podezření na selhání).
        Pokud by se smazalo podezřele moc záznamů (>90 %, server asi vrátil neúplná
        data), neudělá nic a vrátí {'refused': True, ...}.
        Vrací statistiky, nebo None pokud uživatel odmítl potvrzení.
        """
        p = self.progress
        dead_movies, dead_episodes, total_movies, total_episodes =             self._db.find_dead_with_totals(conn, alive_movies, alive_episodes)
        if (self._db.is_suspicious(total_movies, len(dead_movies))
                or self._db.is_suspicious(total_episodes, len(dead_episodes))):
            p.message('POZOR: uklid odmitnut - na serveru chybi {}/{} filmu a {}/{} epizod. '
                      'Server nejspis vratil neuplna data; nic nemazu.'.format(
                          len(dead_movies), total_movies, len(dead_episodes), total_episodes))
            return {'refused': True, 'movies': 0, 'episodes': 0, 'shows': 0, 'paths': 0,
                    'rewritten': 0}
        n_shows = self._db.count_dead_shows(conn, dead_episodes, alive_series)
        n_versions = self._db.count_version_repairs(conn, alive_movies)
        p.message('K smazani: {} filmu, {} epizod (+ prazdne serialy), {} zastaralych verzi filmu'.format(
            len(dead_movies), len(dead_episodes), n_versions))

        if confirm is not None and not confirm(len(dead_movies), len(dead_episodes), n_shows):
            return None

        stats = {'movies': 0, 'episodes': 0, 'shows': 0, 'paths': 0, 'versions': 0}
        pending = dead_movies or dead_episodes or n_shows or n_versions
        if pending and before_delete is not None:
            before_delete()          # např. záloha databáze; při chybě se nic nesmaže
        if pending:
            stats = self._db.delete_dead(conn, dead_movies, dead_episodes, alive_series,
                                         progress=p.progress, alive_movies=alive_movies)
            p.message('Smazano: {} filmu, {} epizod, {} serialu'.format(
                stats['movies'], stats['episodes'], stats['shows']))

        p.progress(95, 'Opravuji adresy serveru a API klic...')
        stats['rewritten'] = self._db.rewrite_urls(
            conn, self._jf.server, self._jf.api_key, progress=p.progress)
        p.message('Prepsano adres/klicu: {}'.format(stats['rewritten']))
        return stats

    CLEANUP_CHECK_MIN_INTERVAL = 6 * 3600   # s, jak často smí rychlá aktualizace stahovat seznamy ID

    def _auto_cleanup_after_incremental(self, conn):
        """
        Po rychlé aktualizaci levně zjistí (3 malé dotazy na počty), jestli je v Kodi víc položek
        z Jellyfinu než na serveru. Jen v tom případě stáhne seznamy ID a smaže zastaralé záznamy.
        """
        p = self.progress
        local = self._db.count_jellyfin(conn)
        server = {'movies': self._jf.count_items('Movie'),
                  'shows': self._jf.count_items('Series'),
                  'episodes': self._jf.count_items('Episode')}
        # samostatné kopie téhož filmu se v Kodi sloučí do jednoho, proto je filmů v Kodi o tolik méně
        server['movies'] = max(server['movies'] - self.state.get('movie_merge_slack', 0), 0)
        # seriály doplněné z epizod (na serveru mimo seznam seriálů) jsou v Kodi navíc oprávněně
        server['shows'] += self.state.get('show_extra', 0)
        if all(local[k] <= server[k] for k in local):
            return None
        if time.time() - self.state.get('last_cleanup_check', 0) < self.CLEANUP_CHECK_MIN_INTERVAL:
            return None
        self.state['last_cleanup_check'] = time.time()
        p.message('V Kodi je víc položek než na serveru (filmy {}/{}, seriály {}/{}, epizody {}/{}) '
                  '- kontroluji zastaralé záznamy...'.format(
                      local['movies'], server['movies'], local['shows'], server['shows'],
                      local['episodes'], server['episodes']))
        alive_movies = self._fetch_ids('Movie')
        alive_series = self._fetch_ids('Series')
        alive_episodes = self._fetch_ids('Episode')
        return self._cleanup(conn, alive_movies, alive_episodes, alive_series,
                             confirm=None, before_delete=self.backup_hook)

    def repair(self, confirm=None):
        """
        Ruční oprava: stáhne ze serveru seznam existujících ID, smaže zastaralé
        (nepřehratelné) záznamy a opraví adresy. confirm(filmy, epizody, serialy)
        -> bool dostane počty před smazáním. Vrací statistiky nebo None.
        """
        self._connect()
        p = self.progress
        conn = self._db._connect()
        try:
            p.progress(5, 'Stahuji seznam filmu ze serveru...')
            alive_movies = self._fetch_ids('Movie')
            p.progress(20, 'Stahuji seznam serialu ze serveru...')
            alive_series = self._fetch_ids('Series')
            p.progress(30, 'Stahuji seznam epizod ze serveru (muze chvili trvat)...')
            alive_episodes = self._fetch_ids('Episode')
            p.message('Na serveru: {} filmu, {} serialu, {} epizod'.format(
                len(alive_movies), len(alive_series), len(alive_episodes)))
            p.progress(50, 'Hledam zastarale zaznamy...')
            return self._cleanup(conn, alive_movies, alive_episodes, alive_series, confirm)
        finally:
            conn.close()

    # ------------------------------------------------------------------
    # Plná synchronizace
    # ------------------------------------------------------------------

    def full_sync(self):
        self._connect()
        p = self.progress
        conn = self._db._connect()

        try:
            # Diagnostika - zaloguj schema DB
            self._db.log_schema(conn)

            # --- Filmy ---
            p.message('Stahuji filmy z Jellyfin...')
            p.progress(5, 'Filmy')
            lib_ids = self._selected_library_ids('movie')
            movies = list(self._jf.get_items('Movie', library_ids=lib_ids))
            p.message('Nalezeno filmů: {}'.format(len(movies)))

            # Více verzí jednoho filmu (sloučené v Jellyfinu i samostatné kopie se stejným TMDb/IMDb ID)
            try:
                details = self._jf.get_items_by_ids(versions_mod.candidate_ids(movies))
                versions_ok = True
            except Exception as e:
                xbmc.log('[JellyfinSync] Podrobnosti o verzich filmu se nepodarilo stahnout ({}) - '
                         'verze se tentokrat nezapisuji'.format(e), xbmc.LOGWARNING)
                details, versions_ok = {}, False
            groups = versions_mod.build_groups(movies, details)
            if versions_ok:
                self.state['movie_merge_slack'] = len(movies) - len(groups)

            p.message('Filmů po sloučení verzí: {} (verzí navíc: {})'.format(
                len(groups), sum(len(g.versions) - 1 for g in groups)))
            self._db.fix_default_version_type(conn)
            removed_art = dedupe_art(conn)
            if removed_art:
                p.message('Odstraneno duplicitnich nahledu: {}'.format(removed_art))

            ok_m = 0
            err_m = 0
            total_m = len(groups)
            batch = BatchWriter(conn)
            for i, g in enumerate(groups):
                m = g.primary
                if p.check_cancel():
                    break
                pct = 5 + int(35 * i / max(total_m, 1))
                if i % 50 == 0:
                    p.progress(pct, '🎬 Filmy: {} / {}  (chyb: {})'.format(ok_m, total_m, err_m))

                url = self._jf.get_stream_url(m['Id'], self._jf.api_key)
                try:
                    with batch.item():
                        movie_id = self._db.upsert_movie(
                            conn,
                            jf_id=m['Id'],
                            title=m.get('Name', ''),
                            year=m.get('ProductionYear'),
                            stream_url=url,
                            overview=m.get('Overview') or ''
                        )
                        if m.get('ProviderIds'):
                            self._db.upsert_provider_ids(conn, movie_id, 'movie', m['ProviderIds'])
                        if versions_ok:
                            versions_mod.apply_versions(
                                conn, movie_id, g.versions,
                                lambda vid: self._jf.get_stream_url(vid, self._jf.api_key))
                    ok_m += 1
                except Exception as e:
                    err_m += 1
                    import traceback
                    xbmc.log('[JellyfinSync] Film chyba {}: {}\n{}'.format(
                        m.get('Name'), e, traceback.format_exc()), xbmc.LOGWARNING)
                    if err_m == 1:  # Prvni chybu loguj podrobne
                        xbmc.log('[JellyfinSync] PRVNI CHYBA DETAIL: ' + traceback.format_exc(), xbmc.LOGERROR)

            batch.flush()
            p.progress(40, '🎬 Filmy: {} / {}  (chyb: {})'.format(ok_m, total_m, err_m))
            p.message('✓ Filmy dokončeny: {}/{}'.format(ok_m, total_m))

            # Nahled (poster) pro filmy
            p.progress(39, 'Stahuji náhledy filmů...')
            _sync_art(conn, self._jf, self._db, [g.primary for g in groups], 'movie', p)

            if p.check_cancel():
                return

            # --- Seriály ---
            p.message('Stahuji seriály z Jellyfin...')
            lib_ids_tv = self._selected_library_ids('tvshow')
            shows_raw = list(self._jf.get_items('Series', library_ids=lib_ids_tv))
            p.message('Nalezeno seriálů: {}'.format(len(shows_raw)))
            if not lib_ids and not lib_ids_tv:          # rejstřík TMDb/IMDb -> Jellyfin (kontextové menu, TMDb Helper)
                try:
                    from resources.lib import movie_index
                    index = movie_index.build_from_items(movies, 'movie')
                    movie_index.save(movie_index.build_from_items(shows_raw, 'series', index))
                except Exception as e:
                    xbmc.log('[JellyfinSync] Rejstrik se nepodarilo ulozit: {}'.format(e), xbmc.LOGWARNING)

            show_map = {}  # jf_id → kodi show_id
            ok_s = 0
            batch = BatchWriter(conn)
            for i, s in enumerate(shows_raw):
                if p.check_cancel():
                    break
                if i % 50 == 0:
                    p.progress(40 + int(10 * i / max(len(shows_raw), 1)),
                               'Seriály {}/{}'.format(i, len(shows_raw)))
                try:
                    with batch.item():
                        show_id = self._db.upsert_show(
                            conn,
                            jf_id=s['Id'],
                            title=s.get('Name', ''),
                            year=s.get('ProductionYear'),
                            overview=s.get('Overview') or ''
                        )
                        show_path = '{}/Shows/{}/'.format(self._jf.server, s['Id'])
                        self._db.link_show_path(conn, show_id, show_path)
                        if s.get('ProviderIds'):
                            self._db.upsert_provider_ids(conn, show_id, 'tvshow', s['ProviderIds'])
                    show_map[s['Id']] = show_id
                    ok_s += 1
                except Exception as e:
                    xbmc.log('[JellyfinSync] Seriál chyba {}: {}'.format(s.get('Name'), e), xbmc.LOGWARNING)

            batch.flush()
            p.message('Seriály: {}/{}'.format(ok_s, len(shows_raw)))

            # Nahled (poster) pro serialy
            p.progress(49, 'Stahuji náhledy seriálů...')
            _sync_art(conn, self._jf, self._db, shows_raw, 'tvshow', p)

            if p.check_cancel():
                return

            # --- Epizody ---
            p.message('Stahuji epizody z Jellyfin...')
            p.progress(50, 'Epizody')
            episodes = list(self._jf.get_items('Episode', library_ids=lib_ids_tv))
            p.message('Nalezeno epizod: {}'.format(len(episodes)))

            # Doplň seriály z epizod (pokud chybí v show_map)
            missing_series = {}
            for ep in episodes:
                sid = ep.get('SeriesId')
                if sid and sid not in show_map:
                    if sid not in missing_series:
                        missing_series[sid] = ep.get('SeriesName', 'Neznámý seriál')

            self.state['show_extra'] = len(missing_series)       # seriály mimo seznam (pro kontrolu počtů)
            for sid, sname in missing_series.items():
                try:
                    with conn:
                        show_id = self._db.upsert_show(conn, jf_id=sid, title=sname, year=None)
                        show_path = '{}/Shows/{}/'.format(self._jf.server, sid)
                        self._db.link_show_path(conn, show_id, show_path)
                    show_map[sid] = show_id
                except Exception:
                    pass

            ok_e = skip_e = 0
            total_e = len(episodes)
            batch = BatchWriter(conn)
            for i, ep in enumerate(episodes):
                if p.check_cancel():
                    break
                if i % 200 == 0:
                    p.progress(50 + int(45 * i / max(total_e, 1)),
                               '📺 Epizody: {} / {}  (přeskočeno: {})'.format(ok_e, total_e, skip_e))

                series_id = ep.get('SeriesId')
                show_id = show_map.get(series_id)
                if not show_id:
                    skip_e += 1
                    continue

                url = self._jf.get_stream_url(ep['Id'], self._jf.api_key)
                try:
                    with batch.item():
                        self._db.upsert_episode(
                            conn,
                            jf_id=ep['Id'],
                            show_id=show_id,
                            title=ep.get('Name', ''),
                            season=ep.get('ParentIndexNumber'),
                            episode=ep.get('IndexNumber'),
                            year=ep.get('ProductionYear'),
                            stream_url=url,
                            overview=ep.get('Overview') or ''
                        )
                    ok_e += 1
                except Exception as e:
                    xbmc.log('[JellyfinSync] Epizoda chyba {}: {}'.format(ep.get('Name'), e), xbmc.LOGWARNING)
                    skip_e += 1

            batch.flush()
            p.progress(95, '📺 Epizody: {} / {}  (přeskočeno: {})'.format(ok_e, total_e, skip_e))
            p.message('✓ Epizody dokončeny: {}/{}'.format(ok_e, total_e))

            # Úklid záznamů, které už na serveru neexistují (např. po změně ID položek).
            # Jen když se synchronizovalo vše (bez výběru knihoven) a server vrátil data.
            if (not lib_ids and not lib_ids_tv and not p.check_cancel()
                    and xbmcaddon.Addon().getSetting('auto_cleanup') != 'false'):
                try:
                    p.message('Uklizim zaznamy, ktere uz na serveru neexistuji...')
                    self._cleanup(
                        conn,
                        set().union(*(g.all_ids for g in groups)) if groups else set(),
                        set(e['Id'] for e in episodes),
                        set(s['Id'] for s in shows_raw))
                except Exception as e:
                    import traceback
                    xbmc.log('[JellyfinSync] Uklid selhal: {}\n{}'.format(e, traceback.format_exc()),
                             xbmc.LOGWARNING)

            # Ulož timestamp
            self.state['last_full_sync'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
            self.state['last_sync'] = self.state['last_full_sync']
            save_state(self.state)

            stats = self._db.get_stats(conn)
            p.progress(100, 'Hotovo')
            p.message('✓ Synchronizace dokončena | Filmů: {} | Seriálů: {} | Epizod: {}'.format(
                stats['movies'], stats['shows'], stats['episodes']))
            # Notifikace s pocty
            p.notify(ok_m, ok_e, 'full')

        finally:
            conn.close()

    # ------------------------------------------------------------------
    # Inkrementální synchronizace
    # ------------------------------------------------------------------

    def incremental_sync(self):
        last = self.state.get('last_sync')
        if not last:
            self.progress.message('Nebyl proveden plný sync – spouštím plný sync')
            return self.full_sync()

        self._connect()
        p = self.progress
        conn = self._db._connect()
        p.message('Inkrementální sync od: {}'.format(last))

        try:
            lib_ids = self._selected_library_ids('movie')
            lib_ids_tv = self._selected_library_ids('tvshow')

            # Nové filmy
            p.progress(10, 'Nové filmy')
            new_movies = list(self._jf.get_items('Movie', library_ids=lib_ids, min_date=last))
            p.message('Nových filmů: {}'.format(len(new_movies)))
            new_groups = versions_mod.build_groups(
                new_movies, self._jf.get_items_by_ids(versions_mod.candidate_ids(new_movies)))
            for g in new_groups:
                m = g.primary
                url = self._jf.get_stream_url(m['Id'], self._jf.api_key)
                try:
                    with conn:
                        movie_id = self._db.upsert_movie(conn, m['Id'], m.get('Name', ''),
                                                         m.get('ProductionYear'), url,
                                                         overview=m.get('Overview') or '')
                        if m.get('ProviderIds'):
                            self._db.upsert_provider_ids(conn, movie_id, 'movie', m['ProviderIds'])
                        versions_mod.apply_versions(
                            conn, movie_id, g.versions,
                            lambda vid: self._jf.get_stream_url(vid, self._jf.api_key))
                except Exception as e:
                    xbmc.log('[JellyfinSync] {}'.format(e), xbmc.LOGWARNING)
            if new_movies:
                _sync_art(conn, self._jf, self._db, new_movies, 'movie', p)

            # Nové seriály (s ID, popisem a vazbou na cestu – dřív vznikaly jen z epizod)
            p.progress(40, 'Nové seriály')
            new_shows = list(self._jf.get_items('Series', library_ids=lib_ids_tv, min_date=last))
            p.message('Nových seriálů: {}'.format(len(new_shows)))
            for s in new_shows:
                try:
                    with conn:
                        sid_kodi = self._db.upsert_show(conn, jf_id=s['Id'], title=s.get('Name', ''),
                                                        year=s.get('ProductionYear'),
                                                        overview=s.get('Overview') or '')
                        self._db.link_show_path(conn, sid_kodi, '{}/Shows/{}/'.format(self._jf.server, s['Id']))
                        if s.get('ProviderIds'):
                            self._db.upsert_provider_ids(conn, sid_kodi, 'tvshow', s['ProviderIds'])
                except Exception as e:
                    xbmc.log('[JellyfinSync] Seriál {}: {}'.format(s.get('Name'), e), xbmc.LOGWARNING)
            if new_shows:
                _sync_art(conn, self._jf, self._db, new_shows, 'tvshow', p)

            # Nové epizody
            p.progress(50, 'Nové epizody')
            new_eps = list(self._jf.get_items('Episode', library_ids=lib_ids_tv, min_date=last))
            p.message('Nových epizod: {}'.format(len(new_eps)))

            # Načti show_map z DB
            all_uid = conn.execute(
                "SELECT value, media_id FROM uniqueid WHERE media_type='tvshow' AND type='jellyfin'"
            ).fetchall()
            show_map = {row[0]: row[1] for row in all_uid}

            for ep in new_eps:
                sid = ep.get('SeriesId')
                show_id = show_map.get(sid)
                if not show_id:
                    # Zkus přidat seriál
                    try:
                        with conn:
                            show_id = self._db.upsert_show(
                                conn, jf_id=sid,
                                title=ep.get('SeriesName', 'Neznámý'),
                                year=None
                            )
                            self._db.link_show_path(
                                conn, show_id, '{}/Shows/{}/'.format(self._jf.server, sid))
                        show_map[sid] = show_id
                    except Exception:
                        continue
                url = self._jf.get_stream_url(ep['Id'], self._jf.api_key)
                try:
                    with conn:
                        self._db.upsert_episode(
                            conn, ep['Id'], show_id,
                            ep.get('Name', ''),
                            ep.get('ParentIndexNumber'),
                            ep.get('IndexNumber'),
                            ep.get('ProductionYear'),
                            url,
                            overview=ep.get('Overview') or ''
                        )
                except Exception as e:
                    xbmc.log('[JellyfinSync] {}'.format(e), xbmc.LOGWARNING)

            if (not lib_ids and not lib_ids_tv and self.backup_hook is not None
                    and not p.check_cancel()
                    and xbmcaddon.Addon().getSetting('auto_cleanup') != 'false'):
                try:
                    cleaned = self._auto_cleanup_after_incremental(conn)
                    if cleaned and not cleaned.get('refused'):
                        p.message('Uklizeno: {} filmů, {} epizod, {} seriálů'.format(
                            cleaned['movies'], cleaned['episodes'], cleaned['shows']))
                except Exception as e:
                    import traceback
                    xbmc.log('[JellyfinSync] Uklid po aktualizaci selhal: {}\n{}'.format(
                        e, traceback.format_exc()), xbmc.LOGWARNING)

            self.state['last_sync'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
            save_state(self.state)

            stats = self._db.get_stats(conn)
            p.progress(100, 'Hotovo')
            p.message('✓ Aktualizace dokončena | +{} filmů, +{} epizod | Celkem: {} filmů, {} epizod'.format(
                len(new_movies), len(new_eps), stats['movies'], stats['episodes']))
            p.notify(len(new_movies), len(new_eps), 'incremental')

        finally:
            conn.close()
