"""
Více verzí jednoho filmu (Kodi 21: tabulka videoversion).

Jellyfin vrací verze dvojím způsobem:
  * sloučené verze – jedna položka s víc zdroji (MediaSources); alternativní zdroje nejsou
    v seznamu položek samostatně, ale jdou přehrát přes /Videos/<id zdroje>/stream,
  * samostatné položky téhož filmu (stejné TMDb/IMDb ID) – např. mkv a mp4 vedle sebe.

build_groups() je spojí do skupin (jeden film = víc verzí) a pojmenuje je,
apply_versions() je zapíše do databáze Kodi:
  movie.idFile = výchozí verze, videoversion = jeden řádek na verzi (idFile, idMedia, idType),
  každá verze má vlastní řádek files (vlastní stav „shlédnuto“, záložky, streamdetails).
Jen standardní knihovna – sdílí PC appka i doplněk pro Kodi.
"""
import logging
import os
import re

from .maintenance import video_id

log = logging.getLogger("jfcore")

DEFAULT_TYPE_ID = 40400          # Kodi: "Standardní edice"
USER_OWNER = 1                   # videoversiontype.owner: 0 = systémový typ, 1 = vytvořený uživatelem
MAX_LABEL = 60


# ----------------------------------------------------------------------
# Skupiny verzí (čistá logika, bez databáze)
# ----------------------------------------------------------------------

class Version:
    """Jedna přehratelná verze: vid = Jellyfin ID použité v adrese /Videos/<vid>/stream."""

    def __init__(self, vid, name="", path="", container="", height=0, owner_id=None, size=0,
                 width=0, streams=None):
        self.vid = vid
        self.size = size or 0             # velikost souboru v bajtech (rozliší jinak stejné verze)
        self.width = width or 0
        self.streams = streams or []      # MediaStreams z Jellyfinu (video/audio/titulky)
        self.name = name or ""            # název zdroje z Jellyfinu (MediaSource.Name)
        self.path = path or ""
        self.container = (container or "").lower()
        self.height = height or 0
        self.owner_id = owner_id or vid   # ID položky v seznamu, ke které verze patří
        self.label = ""

    @property
    def eff_width(self):
        """Šířka obrazu (u širokoúhlých filmů je výška zavádějící: 1920x800 je stále 1080p)."""
        return self.width or int(self.height * 16 / 9)

    def __repr__(self):
        return "Version({!r}, {!r})".format(self.vid, self.label)


class MovieGroup:
    def __init__(self, key, items):
        self.key = key
        self.items = items                # položky ze seznamu Jellyfinu patřící do skupiny
        self.versions = []

    @property
    def primary(self):
        """Položka, ze které se bere název, popis a ID (první v seznamu verzí)."""
        by_id = {i["Id"]: i for i in self.items}
        return by_id.get(self.versions[0].owner_id, self.items[0])

    @property
    def all_ids(self):
        """Všechna Jellyfin ID patřící do skupiny (položky i alternativní zdroje)."""
        return {v.vid for v in self.versions} | {i["Id"] for i in self.items}


def _video_size(source):
    """(šířka, výška) prvního video proudu zdroje."""
    for st in (source or {}).get("MediaStreams") or []:
        if st.get("Type") == "Video":
            return st.get("Width") or 0, st.get("Height") or 0
    return (source or {}).get("Width") or 0, (source or {}).get("Height") or 0


def _make_version(src, owner_id, fallback_path="", fallback_id=None):
    width, height = _video_size(src)
    path = src.get("Path") or fallback_path
    container = src.get("Container") or os.path.splitext(path)[1].lstrip(".")
    return Version(src.get("Id") or fallback_id, src.get("Name"), path, container, height, owner_id,
                   src.get("Size"), width, src.get("MediaStreams"))


YEAR_IN_NAME = re.compile(r"[(\[ ]((?:19|20)\d{2})[)\] ]")


def _file_year(item):
    """Rok z názvu souboru („Film (2024).mkv“), pokud tam je."""
    path = item.get("Path") or ""
    if not path:
        srcs = item.get("MediaSources") or []
        path = (srcs[0].get("Path") if srcs else "") or ""
    base = os.path.basename(path.replace("\\", "/"))
    m = YEAR_IN_NAME.search(base)
    return m.group(1) if m else None


def _group_key(item):
    """
    Totéž ID + stejný rok = jeden film. Rok (z metadat i z názvu souboru) chrání před slučováním
    různých filmů, kterým je na serveru omylem přiřazeno stejné TMDb ID (např. originál a remake).
    """
    ids = item.get("ProviderIds") or {}
    for kind in ("Tmdb", "Imdb"):
        if ids.get(kind):
            return (kind.lower(), str(ids[kind]), item.get("ProductionYear"), _file_year(item))
    return ("id", item["Id"], None, None)


def candidate_ids(items):
    """ID položek, u kterých potřebujeme podrobnosti o zdrojích (MediaSources)."""
    keys = {}
    for i in items:
        keys.setdefault(_group_key(i), []).append(i["Id"])
    out = set()
    for ids in keys.values():
        if len(ids) > 1:
            out.update(ids)
    out.update(i["Id"] for i in items if (i.get("MediaSourceCount") or 0) > 1)
    return sorted(out)


def _versions_of(item, detail):
    """Verze jedné položky: u sloučené všechny její zdroje, jinak jediná."""
    sources = (detail or item).get("MediaSources") or []
    if len(sources) > 1:
        return [_make_version(s, item["Id"]) for s in sources]
    src = dict(sources[0]) if sources else {}
    src["Id"] = item["Id"]
    return [_make_version(src, item["Id"], fallback_path=item.get("Path") or "")]


def build_groups(items, details=None):
    """
    Z položek filmů udělá skupiny (jeden film = jedna skupina s jednou nebo více verzemi).
    details: {id položky: položka s MediaSources} pro ty, které vrátí candidate_ids().
    Pořadí skupin odpovídá první položce skupiny v `items`.
    """
    details = details or {}
    order, groups = [], {}
    for item in items:
        key = _group_key(item)
        if key not in groups:
            groups[key] = MovieGroup(key, [])
            order.append(key)
        groups[key].items.append(item)

    result = []
    for key in order:
        g = groups[key]
        per_item = {i["Id"]: _versions_of(i, details.get(i["Id"])) for i in g.items}
        # hlavní položka: nejvyšší rozlišení, při shodě nejnižší ID (stabilní)
        g.items.sort(key=lambda i: (-max(v.eff_width for v in per_item[i["Id"]]), i["Id"]))
        for it in g.items:
            rest = per_item[it["Id"]]
            g.versions.extend(rest if it is g.items[0] else sorted(rest, key=lambda v: (-v.eff_width, v.vid)))
        _label_versions(g)
        result.append(g)
    return result


# ----------------------------------------------------------------------
# Pojmenování verzí
# ----------------------------------------------------------------------

def _basename(version):
    base = os.path.basename((version.path or "").replace("\\", "/"))
    return os.path.splitext(base)[0] if base else (version.name or "")


BOUNDARY = " -_.)]"
MAX_REST = 30                 # delší rozdíl v názvu souboru už není „štítek verze“


def _tidy(text):
    return re.sub(r"\s+", " ", (text or "").strip(" -_.[]()")).strip()


def _common_prefix(names):
    """Společný začátek názvů souborů, zkrácený na hranici slova."""
    if len(names) < 2:
        return ""
    prefix = os.path.commonprefix(names)
    while prefix and not (prefix[-1] in BOUNDARY
                          or all(len(n) == len(prefix) or n[len(prefix)] in BOUNDARY for n in names)):
        prefix = prefix[:-1]
    return prefix


def _resolution(version):
    """4K / 1440p / 1080p / 720p / SD podle šířky obrazu (bez ní podle výšky)."""
    w = version.width
    if w:
        for limit, name in ((3200, "4K"), (2400, "1440p"), (1700, "1080p"), (1100, "720p")):
            if w >= limit:
                return name
        return "SD"
    h = version.height
    if h >= 2000:
        return "4K"
    if h >= 1000:
        return "1080p"
    if h >= 700:
        return "720p"
    return "SD" if h > 0 else ""


FILE_EXT = re.compile(r"\.(mkv|mp4|avi|ts|m2ts|mov|wmv|iso)$", re.I)


def _composite_label(name):
    """
    Některé zdroje mají už od Jellyfinu informativní název „Webshare · 2160p · CZ · 81.2 GB · soubor.mkv“.
    Zkrátí se na část před názvem souboru: „Webshare · 2160p · CZ · 81.2 GB“. Jinak prázdný text.
    """
    if "·" not in (name or ""):
        return ""
    kept = []
    for part in (p.strip() for p in name.split("·")):
        if not part or len(part) > 28 or FILE_EXT.search(part) or len(kept) >= 4:
            break
        kept.append(part)
    return " · ".join(kept) if len(kept) >= 2 else ""


def _human_size(size):
    if not size:
        return ""
    if size >= 1 << 30:
        return "{:.1f} GB".format(size / float(1 << 30))
    return "{} MB".format(int(size / float(1 << 20)))


def _label_versions(group):
    versions = group.versions
    if len(versions) == 1:
        versions[0].label = ""            # jediná verze: výchozí typ „Standardní edice“
        return
    bases = [_basename(v) for v in versions]
    prefix = _common_prefix(bases)
    # štítek z názvu souboru („... - CZ“, „... - 2 verzia“) jen když se názvy liší jen koncem
    use_names = bool(prefix) and len(prefix) >= 0.6 * min(len(b) for b in bases)
    labels = []
    for v, base in zip(versions, bases):
        composite = _composite_label(v.name)
        rest = _tidy(base[len(prefix):]) if use_names else ""
        labels.append(composite or (rest if len(rest) <= MAX_REST else ""))
    # kde rozdíl v názvu souboru chybí, rozliší rozlišení, pak formát, pak velikost souboru
    for idx, v in enumerate(versions):
        if not labels[idx]:
            labels[idx] = _resolution(v)

    def refine(extra):
        duplicated = {l for l in labels if l and labels.count(l) > 1}
        for idx, v in enumerate(versions):
            text = extra(v)
            if text and (not labels[idx] or labels[idx] in duplicated):
                labels[idx] = "{} {}".format(labels[idx], text).strip()

    refine(lambda v: v.container.upper())
    refine(lambda v: _human_size(v.size))
    seen = {}
    for idx, v in enumerate(versions):
        label = labels[idx] or "Verze {}".format(idx + 1)
        seen[label] = seen.get(label, 0) + 1
        if seen[label] > 1:
            label = "{} ({})".format(label, seen[label])
        v.label = label[:MAX_LABEL]


# ----------------------------------------------------------------------
# Zápis do databáze Kodi
# ----------------------------------------------------------------------

def split_stream_url(url):
    """'https://h/Videos/<id>/stream?x=1' -> ('https://h/Videos/<id>/', 'stream?x=1')."""
    if "?" in url:
        base, query = url.split("?", 1)
        return base.rsplit("/", 1)[0] + "/", base.rsplit("/", 1)[-1] + "?" + query
    return url.rsplit("/", 1)[0] + "/", url.rsplit("/", 1)[-1]


def _columns(conn, table):
    return {r[1] for r in conn.execute("PRAGMA table_info({})".format(table))}


def _has_table(conn, name):
    return conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (name,)).fetchone() is not None


def type_id_for(conn, label):
    """Id typu verze (videoversiontype) podle názvu; chybějící se založí jako uživatelský."""
    if not label:
        return DEFAULT_TYPE_ID
    row = conn.execute("SELECT id FROM videoversiontype WHERE name=? ORDER BY id LIMIT 1", (label,)).fetchone()
    if row:
        return row[0]
    return conn.execute("INSERT INTO videoversiontype (name, owner, itemType) VALUES (?,?,0)",
                        (label, USER_OWNER)).lastrowid


def find_file(conn, vid):
    """(idFile, idMovie nebo None) souboru, jehož cesta je .../Videos/<vid>/; jinak None."""
    row = conn.execute(
        "SELECT f.idFile, m.idMovie FROM path p JOIN files f ON f.idPath=p.idPath "
        "LEFT JOIN movie m ON m.idFile=f.idFile WHERE p.strPath LIKE ? ORDER BY f.idFile LIMIT 1",
        ("%/Videos/{}/".format(vid),)).fetchone()
    return (row[0], row[1]) if row else None


def _ensure_file(conn, vid, url):
    path_url, filename = split_stream_url(url)
    pcols = _columns(conn, "path")
    row = conn.execute("SELECT idPath FROM path WHERE strPath=?", (path_url,)).fetchone()
    if row:
        id_path = row[0]
    else:
        cols, vals = ["strPath"], [path_url]
        for col, val in (("strContent", "movies"), ("strScraper", "metadata.local"), ("noUpdate", 1)):
            if col in pcols:
                cols.append(col); vals.append(val)
        id_path = conn.execute("INSERT INTO path ({}) VALUES ({})".format(",".join(cols), ",".join("?" * len(vals))),
                               vals).lastrowid
    row = conn.execute("SELECT idFile, strFilename FROM files WHERE idPath=? ORDER BY idFile LIMIT 1",
                       (id_path,)).fetchone()
    if row:
        if row[1] != filename:
            conn.execute("UPDATE files SET strFilename=? WHERE idFile=?", (filename, row[0]))
        return row[0]
    fcols = _columns(conn, "files")
    if "dateAdded" in fcols:
        return conn.execute("INSERT INTO files (idPath, strFilename, dateAdded) VALUES (?,?,datetime('now'))",
                            (id_path, filename)).lastrowid
    return conn.execute("INSERT INTO files (idPath, strFilename) VALUES (?,?)", (id_path, filename)).lastrowid


def write_streamdetails(conn, file_id, streams):
    """Video/audio/titulkové stopy souboru do tabulky streamdetails (stejně jako Kodi při skenu)."""
    if not streams:
        return
    conn.execute("DELETE FROM streamdetails WHERE idFile=?", (file_id,))
    for st in streams:
        kind = (st.get("Type") or "").lower()
        codec = (st.get("Codec") or "").lower()
        lang = (st.get("Language") or "").lower()
        if kind == "video":
            conn.execute(
                "INSERT INTO streamdetails (idFile,iStreamType,strVideoCodec,fVideoAspect,iVideoWidth,"
                "iVideoHeight,iVideoDuration,strVideoLanguage) VALUES (?,0,?,?,?,?,?,?)",
                (file_id, codec, st.get("AspectRatio") or 0, st.get("Width") or 0, st.get("Height") or 0,
                 int((st.get("RunTimeTicks") or 0) / 10_000_000), lang))
        elif kind == "audio":
            conn.execute(
                "INSERT INTO streamdetails (idFile,iStreamType,strAudioCodec,iAudioChannels,strAudioLanguage) "
                "VALUES (?,1,?,?,?)", (file_id, codec, st.get("Channels") or 0, lang))
        elif kind == "subtitle":
            conn.execute("INSERT INTO streamdetails (idFile,iStreamType,strSubtitleLanguage) VALUES (?,2,?)",
                         (file_id, lang))


def apply_versions(conn, movie_id, versions, url_for):
    """
    Zapíše verze filmu `movie_id` (první verze = výchozí). Existující samostatné filmy, které
    jsou ve skutečnosti další verzí, se sloučí (jejich soubor i stav „shlédnuto“ zůstane),
    verze, které už na serveru nejsou, se odstraní. Vrací {'versions','absorbed','removed'}.
    """
    stats = {"versions": 0, "absorbed": 0, "removed": 0}
    if not _has_table(conn, "videoversion") or not versions:
        return stats
    default_file = conn.execute("SELECT idFile FROM movie WHERE idMovie=?", (movie_id,)).fetchone()
    if not default_file:
        return stats
    default_file = default_file[0]

    if len(versions) == 1:                        # rychlá cesta: nic víc než jedna verze
        n = conn.execute("SELECT COUNT(*) FROM videoversion WHERE idMedia=? AND media_type='movie'",
                         (movie_id,)).fetchone()[0]
        if n <= 1:
            return stats

    file_ids, watched = [], []
    for idx, v in enumerate(versions):
        found = find_file(conn, v.vid)
        if found and found[1] is not None and found[1] != movie_id:
            # samostatný film, který je ve skutečnosti další verzí -> sloučit
            pc = conn.execute("SELECT playCount, lastPlayed FROM files WHERE idFile=?", (found[0],)).fetchone()
            if pc and pc[0]:
                watched.append((pc[0], pc[1]))
            conn.execute("DELETE FROM movie WHERE idMovie=?", (found[1],))
            stats["absorbed"] += 1
        fid = found[0] if found else _ensure_file(conn, v.vid, url_for(v.vid))
        if found:
            path_url, filename = split_stream_url(url_for(v.vid))
            conn.execute("UPDATE files SET strFilename=? WHERE idFile=? AND strFilename<>?", (filename, fid, filename))
        file_ids.append(fid)

    if default_file not in file_ids:
        conn.execute("UPDATE movie SET idFile=? WHERE idMovie=?", (file_ids[0], movie_id))
    default_file = conn.execute("SELECT idFile FROM movie WHERE idMovie=?", (movie_id,)).fetchone()[0]

    single = len(versions) == 1
    for v, fid in zip(versions, file_ids):
        if not single:
            write_streamdetails(conn, fid, v.streams)
        type_id = DEFAULT_TYPE_ID if single else type_id_for(conn, v.label)
        conn.execute("INSERT OR REPLACE INTO videoversion (idFile, idMedia, media_type, itemType, idType) "
                     "VALUES (?,?,'movie',0,?)", (fid, movie_id, type_id))
        stats["versions"] += 1

    # verze, které už neexistují (např. sloučení zrušeno, soubor smazán)
    stale = [r[0] for r in conn.execute(
        "SELECT vv.idFile FROM videoversion vv JOIN files f ON f.idFile=vv.idFile JOIN path p ON p.idPath=f.idPath "
        "WHERE vv.idMedia=? AND vv.media_type='movie' AND vv.itemType=0 AND p.strPath LIKE '%/Videos/%'",
        (movie_id,)) if r[0] not in file_ids]
    for fid in stale:
        conn.execute("DELETE FROM files WHERE idFile=?", (fid,))          # trigger smaže i videoversion
        stats["removed"] += 1

    # „shlédnuto“ u sloučené kopie přenést na výchozí verzi (Kodi ukazuje stav výchozí verze)
    if watched:
        cur = conn.execute("SELECT playCount FROM files WHERE idFile=?", (default_file,)).fetchone()
        if cur is not None and not cur[0]:
            best = max(watched, key=lambda w: w[0] or 0)
            conn.execute("UPDATE files SET playCount=?, lastPlayed=? WHERE idFile=?", (best[0], best[1], default_file))
    return stats
