"""
Oprava zasekávání Kodi 21.2 po zastavení přehrávání z Jellyfinu.

Kodi 21.2 se při přehrávání přes HTTPS s HTTP/2 po zastavení filmu zasekne: vlákno, které čte
stream, se točí naprázdno a zavření přehrávače na něj čeká navždy (Kodi „neodpovídá“).
Ověřeno: s <network><disablehttp2>true</disablehttp2></network> v advancedsettings.xml se
přehrávač zavře okamžitě. Soubor se jen doplní – ostatní nastavení i komentáře zůstanou,
původní se zazálohuje. Projeví se po restartu Kodi.
"""
import os
import re
import shutil
import xml.etree.ElementTree as ET

import xbmc

try:
    import xbmcvfs
    _translate = xbmcvfs.translatePath
except (ImportError, AttributeError):
    _translate = xbmc.translatePath

PROFILE_DIR = 'special://profile/'
ADVANCED_NAME = 'advancedsettings.xml'
BACKUP_SUFFIX = '.pred_jellyfinsync'
LAST_AFFECTED = (21, 2)          # vyšší verze (21.3 na PC) potíž nevykazovaly


def kodi_version():
    """(major, minor) běžícího Kodi, např. (21, 2); (0, 0) když nejde zjistit."""
    m = re.match(r'\s*(\d+)\.(\d+)', xbmc.getInfoLabel('System.BuildVersion') or '')
    return (int(m.group(1)), int(m.group(2))) if m else (0, 0)


def affected():
    version = kodi_version()
    return version != (0, 0) and version <= LAST_AFFECTED


def _path():
    return os.path.join(_translate(PROFILE_DIR), ADVANCED_NAME)


def _parse(path):
    parser = ET.XMLParser(target=ET.TreeBuilder(insert_comments=True))
    return ET.parse(path, parser=parser)


def http2_disabled():
    path = _path()
    if not os.path.exists(path):
        return False
    try:
        node = _parse(path).getroot().find('network/disablehttp2')
    except ET.ParseError:
        return False
    return node is not None and (node.text or '').strip().lower() == 'true'


def disable_http2():
    """Doplní <network><disablehttp2>true</disablehttp2></network>. Vrací 'written' / 'already' / 'invalid'."""
    path = _path()
    if os.path.exists(path):
        try:
            tree = _parse(path)
        except ET.ParseError:
            return 'invalid'                      # cizí rozbitý soubor nepřepisovat
        root = tree.getroot()
        if root.tag != 'advancedsettings':
            return 'invalid'
        network = root.find('network')
        if network is None:
            network = ET.SubElement(root, 'network')
        node = network.find('disablehttp2')
        if node is not None and (node.text or '').strip().lower() == 'true':
            return 'already'
        if node is None:
            node = ET.SubElement(network, 'disablehttp2')
        node.text = 'true'
        if not os.path.exists(path + BACKUP_SUFFIX):
            shutil.copy2(path, path + BACKUP_SUFFIX)
        tree.write(path, encoding='utf-8', xml_declaration=False)
        return 'written'
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        f.write('<advancedsettings version="1.0">\n'
                '  <network>\n'
                '    <!-- Jellyfin Sync: Kodi 21.2 se po zastaveni HTTPS streamu zasekava; vypnuto HTTP/2 -->\n'
                '    <disablehttp2>true</disablehttp2>\n'
                '  </network>\n'
                '</advancedsettings>\n')
    return 'written'


def offer_fix(dlg, from_menu=False):
    """
    Nabídne opravu, pokud se Kodi týká (z menu i u jiných verzí, s vysvětlením).
    Vrací výsledek disable_http2(), nebo None, když se nic nedělalo.
    """
    if http2_disabled():
        if from_menu:
            dlg.ok('Jellyfin Sync', 'Oprava uz je nastavena (HTTP/2 je vypnute). Kodi by se po zastaveni '
                                    'filmu nemelo zasekavat.')
        return None
    version = kodi_version()
    if not affected() and not from_menu:
        return None
    note = ('Tato verze Kodi ({}.{}) se pri prehravani z Jellyfinu po zastaveni filmu zasekava.'
            .format(*version) if affected() else
            'Tato verze Kodi ({}.{}) potiz nejspis nema, oprava ale nicemu neuskodi.'.format(*version))
    if not dlg.yesno('Jellyfin Sync - zasekavani po zastaveni filmu',
                     note + '\n\nVypnout HTTP/2 pro sitove streamy? (Zapise se do advancedsettings.xml, '
                            'puvodni soubor se zazalohuje. Projevi se po restartu Kodi.)'):
        return None
    result = disable_http2()
    if result == 'invalid':
        dlg.ok('Jellyfin Sync', 'Soubor advancedsettings.xml existuje, ale neni platny - nemenil jsem ho.\n'
                                'Dopln do nej rucne: <network><disablehttp2>true</disablehttp2></network>')
    elif result == 'written':
        dlg.ok('Jellyfin Sync', 'Hotovo. Restartuj prosim Kodi, aby se oprava projevila.')
    return result
