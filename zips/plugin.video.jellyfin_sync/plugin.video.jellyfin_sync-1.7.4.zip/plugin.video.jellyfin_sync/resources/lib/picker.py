"""
Výběr verze filmu / epizody na Jellyfinu – sdílí kontextové menu (context.py) a přehrávač
pro TMDb Helper (default.py ?action=play_tmdb).

Verze se zjišťují dotazem na jednotlivou položku – jen tak server přidá i živé zdroje
z pluginů (Webshare/Fastshare), které u hromadných dotazů vynechává.
"""
import xbmc
import xbmcgui

from resources.lib import movie_index
from resources.lib.jfcore import versions

HEADING = 'Jellyfin - verze'


class NotFound(Exception):
    pass


def connect():
    from resources.lib.sync_engine import SyncEngine, SyncProgress
    engine = SyncEngine(progress=SyncProgress())
    engine._connect()
    return engine._jf


def _details(jf, ids):
    details = {}
    for item_id in ids:
        details.update(jf.get_items_by_ids([item_id], fields='MediaSources,Path'))
    return details


def _pick_group(groups, vid, year):
    """Při chybně přiřazeném TMDb ID na serveru může vzniknout víc skupin – vezme tu pravou."""
    if len(groups) == 1:
        return groups[0]
    for g in groups:
        if vid and vid in g.all_ids:
            return g
    for g in groups:
        if year and str(g.primary.get('ProductionYear') or '') == str(year):
            return g
    return max(groups, key=lambda g: len(g.versions))


def _options(group, current=None):
    return [('{}{}'.format(v.label or 'Standardni verze', '  [aktualni]' if v.vid == current else ''), v.vid)
            for v in group.versions]


def movie_options(jf, vid=None, tmdb='', imdb='', year=''):
    """(skupina, [(popisek, id zdroje)]) pro film; NotFound, když na serveru není."""
    ids = movie_index.lookup(jf, tmdb, imdb, kind='movie') if (tmdb or imdb) else []
    if vid and vid not in ids:
        ids.insert(0, vid)
    details = _details(jf, ids)
    items = [details[i] for i in ids if i in details and (details[i].get('MediaSources') or [])]
    if not items:
        raise NotFound('Tento film na Jellyfinu neni.')
    group = _pick_group(versions.build_groups(items, details), vid, year)
    return group, _options(group, vid)


def episode_options(jf, season, episode, tmdb='', imdb='', tvdb=''):
    """(epizoda, [(popisek, id zdroje)]) pro epizodu seriálu; NotFound, když na serveru není."""
    series_ids = movie_index.lookup(jf, tmdb, imdb, kind='series', tvdb=tvdb)
    for sid in series_ids:
        result = jf.request('/Shows/{}/Episodes'.format(sid), params={
            'UserId': jf.user_id, 'Season': str(season), 'Fields': 'MediaSources,Path'})
        for ep in result.get('Items', []):
            if str(ep.get('IndexNumber')) == str(episode) and str(ep.get('ParentIndexNumber')) == str(season):
                details = _details(jf, [ep['Id']]) or {ep['Id']: ep}
                item = details.get(ep['Id'], ep)
                group = versions.build_groups([item], {item['Id']: item})[0]
                return item, _options(group)
    raise NotFound('Tato epizoda na Jellyfinu neni.')


def choose(options, heading=HEADING, always_ask=False):
    """Id vybraného zdroje (None = zrušeno). U jediné verze se neptá, pokud není always_ask."""
    if len(options) == 1 and not always_ask:
        return options[0][1]
    choice = xbmcgui.Dialog().select(heading, [text for text, _ in options])
    return None if choice < 0 else options[choice][1]


def stream_url(jf, source_id):
    return jf.get_stream_url(source_id, jf.api_key)


def busy(on):
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)' if on else 'Dialog.Close(busydialognocancel)')
