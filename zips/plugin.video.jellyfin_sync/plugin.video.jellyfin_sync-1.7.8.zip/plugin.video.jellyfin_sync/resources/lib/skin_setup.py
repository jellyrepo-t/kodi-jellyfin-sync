"""
Krok „Vzhled“: nainstaluje skin Arctic Fuse 3 (od autora, z jeho repozitáře), zapíše přednastavení
úvodní obrazovky a widgetů (plné / lehké) a přepne na něj Kodi.

Přednastavení je v resources/skin_presets/skin.arctic.fuse.3/<plne|lehke>/:
    settings.xml -> addon_data/skin.arctic.fuse.3/settings.xml        (nastavení skinu)
    nodes/*.json -> addon_data/script.skinvariables/nodes/skin.arctic.fuse.3/  (úvodní obrazovka)

Když už Arctic Fuse 3 běží, Kodi drží jeho nastavení v paměti a při ukončení by zapsaný soubor
přepsalo – nastavení se pak předá příkazy Skin.SetBool/SetString a skin se znovu načte.
"""
import json
import os
import re
import shutil

import xbmc
import xbmcaddon
import xbmcgui

try:
    import xbmcvfs
    _translate = xbmcvfs.translatePath
except (ImportError, AttributeError):
    _translate = xbmc.translatePath

SKIN = 'skin.arctic.fuse.3'
SETTINGS_DIR = 'special://profile/addon_data/{}/'.format(SKIN)
NODES_DIR = 'special://profile/addon_data/script.skinvariables/nodes/{}/'.format(SKIN)
BACKUP_SUFFIX = '.pred_jellyfinsync'
PRESETS = [
    ('light', 'Arctic Fuse 3 - lehke nastaveni (doporuceno pro TV boxy a Google TV)'),
    ('full', 'Arctic Fuse 3 - plne nastaveni (vic widgetu a efektu)'),
    (None, 'Nechat soucasny vzhled'),
]
SETTING_RE = re.compile(r'<setting id="([^"]+)" type="([^"]+)">([^<]*)</setting>')


def preset_dir(name):
    base = xbmcaddon.Addon().getAddonInfo('path')
    if base.startswith('special://'):
        base = _translate(base)
    return os.path.join(base, 'resources', 'skin_presets', SKIN, name)


def has_addon(addon_id):
    return bool(xbmc.getCondVisibility('System.HasAddon({})'.format(addon_id)))


def skin_active():
    return xbmc.getSkinDir() == SKIN


def has_own_config():
    return os.path.exists(os.path.join(_translate(SETTINGS_DIR), 'settings.xml'))


# Dotaz Kodi na instalaci (= InstallAddon skin našel) a průběh stahování. Vlastní průběhový dialog
# (DialogProgressBG = extendedprogressdialog) proto doplněk během čekání nezobrazuje – Kodi by ho
# nerozlišilo od instalace a doplněk by InstallAddon nikdy neposlal.
CONFIRM_DIALOGS = 'Window.IsActive(yesnodialog) | Window.IsActive(addoninformation)'
PROGRESS_DIALOGS = 'Window.IsActive(progressdialog) | Window.IsActive(extendedprogressdialog)'


def _jsonrpc(method, params):
    try:
        reply = xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params}))
        return json.loads(reply).get('result')
    except Exception:
        return None


UPDATE_MODE = 'addons.updatemode'            # 0 = jen oficiální repozitáře, 1 = všechny


def allow_updates_from_any_repository(dlg):
    """
    Arctic Fuse 3 potřebuje novější verze některých doplňků (např. script.skinvariables), než má
    oficiální repozitář Kodi. Při výchozím „jen oficiální repozitáře“ Kodi instalaci odmítne
    („závislost nelze splnit“) – s dovolením uživatele se proto na dobu instalace povolí i ostatní
    repozitáře. Vrací (povoleno, původní_režim): původní režim je None, když se nic nezměnilo;
    po instalaci se vrací přes restore_update_mode().
    """
    current = _jsonrpc('Settings.GetSettingValue', {'setting': UPDATE_MODE})
    if current is None or (current or {}).get('value') != 0:
        return True, None
    if not dlg.yesno('Vzhled', 'Arctic Fuse 3 potrebuje novejsi verze nekterych doplnku, nez ma oficialni '
                               'repozitar Kodi.\n\nNa dobu instalace povolit doplnky i z ostatnich '
                               'repozitaru? (Po instalaci se nastaveni vrati zpet.)'):
        return False, None
    _jsonrpc('Settings.SetSettingValue', {'setting': UPDATE_MODE, 'value': 1})
    return True, current['value']


def restore_update_mode(previous):
    """Vrátí režim aktualizací doplňků, který byl před instalací skinu."""
    if previous is not None:
        _jsonrpc('Settings.SetSettingValue', {'setting': UPDATE_MODE, 'value': previous})


def install_skin(monitor=None, timeout=300, retry_every=15, give_up_after_prompt=30):
    """
    Nechá Kodi nainstalovat skin (i se závislostmi). Vrací True, když je nainstalovaný.

    Repozitář přidaný až za běhu Kodi ještě nemá stažený seznam doplňků a InstallAddon pak skin
    potichu nenajde. Proto se nejdřív vyžádá aktualizace repozitářů a instalace se zkouší znovu,
    dokud Kodi nenabídne potvrzení. Když uživatel instalaci odmítne, nečeká se zbytečně.
    """
    if has_addon(SKIN):
        return True
    monitor = monitor or xbmc.Monitor()
    xbmc.executebuiltin('UpdateAddonRepos')
    prompted, idle, next_try = False, 0, 3          # chvíli počkat, než se repozitáře stáhnou
    for second in range(timeout):
        if has_addon(SKIN):
            return True
        if xbmc.getCondVisibility(CONFIRM_DIALOGS):
            prompted, idle = True, 0
        elif prompted:
            if xbmc.getCondVisibility(PROGRESS_DIALOGS):
                idle = 0                             # stahuje se
            else:
                idle += 1
                if idle >= give_up_after_prompt:     # dialog zavřen a nic se neinstaluje = odmítnuto
                    return has_addon(SKIN)
        elif second >= next_try:
            xbmc.log('[JellyfinSync] InstallAddon({})'.format(SKIN), xbmc.LOGINFO)
            xbmc.executebuiltin('InstallAddon({})'.format(SKIN))
            next_try = second + retry_every
        if monitor.waitForAbort(1):
            return False
    return has_addon(SKIN)


def _backup(path):
    if os.path.exists(path) and not os.path.exists(path + BACKUP_SUFFIX):
        shutil.copy2(path, path + BACKUP_SUFFIX)


def _write_nodes(src):
    dst = _translate(NODES_DIR)
    os.makedirs(dst, exist_ok=True)
    for fn in sorted(os.listdir(os.path.join(src, 'nodes'))):
        if fn.endswith('.json'):
            _backup(os.path.join(dst, fn))
            shutil.copy(os.path.join(src, 'nodes', fn), os.path.join(dst, fn))


def _quote(value):
    return '"{}"'.format(value.replace('\\', '\\\\').replace('"', '\\"'))


def _live_commands(settings_xml):
    """Příkazy Kodi, které nastavení předají běžícímu skinu."""
    cmds = []
    for key, kind, value in SETTING_RE.findall(settings_xml):
        if kind == 'bool':
            cmds.append(('Skin.SetBool({})' if value.strip() == 'true' else 'Skin.Reset({})').format(key))
        elif value:
            cmds.append('Skin.SetString({},{})'.format(key, _quote(value)))
        else:
            cmds.append('Skin.Reset({})'.format(key))
    return cmds


def apply_preset(name):
    """Zapíše přednastavení. Vrací 'file' (skin neběží, načte se při přepnutí) nebo 'live'."""
    src = preset_dir(name)
    with open(os.path.join(src, 'settings.xml'), encoding='utf-8') as f:
        settings_xml = f.read()
    _write_nodes(src)
    if skin_active():
        for cmd in _live_commands(settings_xml):
            xbmc.executebuiltin(cmd)
        return 'live'
    dst = _translate(SETTINGS_DIR)
    os.makedirs(dst, exist_ok=True)
    _backup(os.path.join(dst, 'settings.xml'))
    with open(os.path.join(dst, 'settings.xml'), 'w', encoding='utf-8') as f:
        f.write(settings_xml)
    return 'file'


def switch_skin():
    """Přepne vzhled; Kodi se samo zeptá, jestli změnu ponechat."""
    xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": "Settings.SetSettingValue",
                                    "params": {"setting": "lookandfeel.skin", "value": SKIN}}))


def run_interactive(monitor=None):
    """Výběr vzhledu (z průvodce i z menu). Vrací True, když se vzhled nastavil."""
    dlg = xbmcgui.Dialog()
    choice = dlg.select('Vzhled Kodi', [label for _, label in PRESETS])
    if choice < 0 or PRESETS[choice][0] is None:
        return False
    name = PRESETS[choice][0]

    if not has_addon(SKIN):
        allowed, previous_mode = allow_updates_from_any_repository(dlg)
        if not allowed:
            dlg.ok('Vzhled', 'Bez povoleni ostatnich repozitaru Kodi Arctic Fuse 3 nenainstaluje.')
            return False
        dlg.notification('Jellyfin Sync', 'Instaluji Arctic Fuse 3 - potvrd instalaci', xbmcgui.NOTIFICATION_INFO, 5000)
        try:
            installed = install_skin(monitor)
        finally:
            restore_update_mode(previous_mode)
        if not installed:
            dlg.ok('Vzhled', 'Arctic Fuse 3 se nepodarilo nainstalovat.\n'
                   'Je v Kodi pridany repozitar JellyKodiSync (nebo repozitar jurialmunkey)?')
            return False
    try:                                                    # TMDb Helper přišel jako závislost skinu
        from resources.lib import tmdbhelper_player
        tmdbhelper_player.install()
    except Exception as e:
        xbmc.log('[JellyfinSync] Prehravac pro TMDb Helper: {}'.format(e), xbmc.LOGWARNING)

    if has_own_config() and not dlg.yesno(
            'Vzhled', 'Arctic Fuse 3 uz ma vlastni nastaveni. Nahradit ho prednastavenim?\n'
                      '(Puvodni soubory se zazalohuji vedle s priponou {}.)'.format(BACKUP_SUFFIX)):
        if not skin_active():
            switch_skin()
        return True

    mode = apply_preset(name)
    if mode == 'live':
        xbmc.executebuiltin('ReloadSkin()')
    else:
        switch_skin()
    xbmc.log('[JellyfinSync] Vzhled: prednastaveni {} ({})'.format(name, mode), xbmc.LOGINFO)
    return True
