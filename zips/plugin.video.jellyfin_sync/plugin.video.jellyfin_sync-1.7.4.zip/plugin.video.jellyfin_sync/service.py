"""
Jellyfin Sync – background service
- Rychlá aktualizace při startu Kodi
- Plný sync každý den v nastavenou dobu
- Provádí úlohy zadané z menu addonu (plná synchronizace, aktualizace, čištění)
  na pozadí, aby se neblokovalo rozhraní Kodi
"""
import time
import datetime
import xbmc
import xbmcaddon

ADDON_ID = 'plugin.video.jellyfin_sync'
STARTUP_DELAY = 30       # s po startu Kodi, než proběhne rychlá aktualizace
LOOP_TICK = 2            # s, jak často služba hledá požadavky z menu
SCHEDULE_CHECK = 30      # s, jak často kontroluje čas nočního syncu


def get_addon():
    return xbmcaddon.Addon()


def log(msg):
    xbmc.log('[JellyfinSync Service] ' + msg, xbmc.LOGINFO)


def should_sync_today(last_sync_date):
    return last_sync_date != datetime.date.today().isoformat()


class SyncService(xbmc.Monitor):
    def __init__(self):
        super(SyncService, self).__init__()
        self.settings_changed = False

    def onSettingsChanged(self):
        self.settings_changed = True
        log('Nastavení změněno.')


def run_scheduled_full(runner):
    result = runner.run('full')
    if result['ok'] and not result['cancelled']:
        from resources.lib.sync_engine import load_state, save_state
        state = load_state()
        state['last_auto_sync_date'] = datetime.date.today().isoformat()
        save_state(state)


def main():
    from resources.lib import jobs

    monitor = SyncService()
    log('Služba spuštěna.')
    try:
        from resources.lib import tmdbhelper_player
        tmdbhelper_player.install()
    except Exception as e:
        log('Přehrávač pro TMDb Helper se nepodařilo zapsat: {}'.format(e))
    jobs.start_heartbeat(monitor)
    runner = jobs.JobRunner(monitor, log=log)

    started = time.time()
    startup_done = False
    next_schedule_check = 0

    while not monitor.abortRequested():
        # 1) úloha zadaná z menu addonu
        kind = jobs.pop_request()
        if kind:
            runner.run(kind)
            continue

        now = time.time()
        addon = get_addon()
        server = addon.getSetting('server_url')
        auto_sync = addon.getSetting('auto_sync') != 'false'

        # 2) rychlá aktualizace po startu Kodi
        if not startup_done and now - started >= STARTUP_DELAY:
            startup_done = True
            if server and auto_sync:
                runner.run('incremental')
                continue
            elif not server:
                log('Server není nastaven, přeskakuji rychlou aktualizaci.')

        # 3) noční plný sync
        if now >= next_schedule_check:
            next_schedule_check = now + SCHEDULE_CHECK
            if auto_sync and server:
                try:
                    sync_hour = int(addon.getSetting('sync_hour') or '2')
                    sync_minute = int(addon.getSetting('sync_minute') or '0')
                except ValueError:
                    sync_hour, sync_minute = 2, 0
                dt = datetime.datetime.now()
                try:
                    from resources.lib.sync_engine import load_state
                    last_date = load_state().get('last_auto_sync_date', '')
                except Exception:
                    last_date = ''
                if dt.hour == sync_hour and dt.minute == sync_minute and should_sync_today(last_date):
                    run_scheduled_full(runner)
                    continue

        if monitor.waitForAbort(LOOP_TICK):
            break

    log('Služba ukončena.')


if __name__ == '__main__':
    main()
