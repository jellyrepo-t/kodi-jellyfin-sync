"""
Minimální Jellyfin klient postavený jen na stdlib.

Důležité poznatky, které jsou tu zapsané kódem:
  * Jellyfin 12+ odmítá starou hlavičku X-Emby-Authorization (400 na login,
    401 na ostatní dotazy) – vyžaduje standardní Authorization.
  * Chyby vždy vyhazují JellyfinError s HTTP kódem a tělem odpovědi, aby se
    dalo poznat, proč server požadavek odmítl (a nikdy se "prázdný výsledek"
    nepleťe se selháním).
"""
import json
import logging
import socket
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

log = logging.getLogger("jfcore")

DEFAULT_FIELDS = "ProviderIds,DateCreated,ProductionYear,OfficialRating,Overview"
EPISODE_FIELDS = ",SeriesId,SeriesName,SeasonId,IndexNumber,ParentIndexNumber"
MOVIE_FIELDS = ",MediaSourceCount,Path"      # počet zdrojů (sloučené verze) a cesta k souboru


class JellyfinError(Exception):
    """Chyba komunikace s Jellyfin. status = HTTP kód (None při síťové chybě)."""

    def __init__(self, message, status=None, body=""):
        super().__init__(message)
        self.status = status
        self.body = body


def parse_version(text):
    """'12.1.0' -> (12, 1, 0); nečitelné části se berou jako 0."""
    parts = []
    for p in (text or "").split(".")[:3]:
        digits = "".join(c for c in p if c.isdigit())
        parts.append(int(digits) if digits else 0)
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts)


class JellyfinClient:
    def __init__(self, server_url, username="", password="",
                 client_name="JellyfinKodiSync", device_name="KodiSyncApp",
                 device_id="kodi-sync-app-001", client_version="2.0.0",
                 timeout=60):
        self.server = (server_url or "").rstrip("/")
        self.username = username
        self.password = password
        self.client_name = client_name
        self.device_name = device_name
        self.device_id = device_id
        self.client_version = client_version
        self.timeout = timeout
        self.user_id = None
        self.token = None
        self.api_key = None
        self.server_version = ""

    # ------------------------------------------------------------------
    # Nízká úroveň
    # ------------------------------------------------------------------

    def auth_header(self, token=None):
        parts = [
            'MediaBrowser Client="{}"'.format(self.client_name),
            'Device="{}"'.format(self.device_name),
            'DeviceId="{}"'.format(self.device_id),
            'Version="{}"'.format(self.client_version),
        ]
        tok = token if token is not None else self.token
        if tok:
            parts.append('Token="{}"'.format(tok))
        return ", ".join(parts)

    def request(self, path, method="GET", body=None, params=None,
                timeout=None, token=None, log_errors=True):
        """Provede požadavek a vrátí rozparsované JSON (nebo {} při prázdné odpovědi)."""
        url = self.server + path
        if params:
            url += ("&" if "?" in url else "?") + urlencode(params)
        data = json.dumps(body).encode("utf-8") if body is not None else None
        req = Request(url, data=data, method=method)
        req.add_header("Authorization", self.auth_header(token))
        req.add_header("Accept", "application/json")
        if data is not None:
            req.add_header("Content-Type", "application/json")
        try:
            with urlopen(req, timeout=timeout or self.timeout) as resp:
                raw = resp.read()
        except HTTPError as e:
            try:
                text = e.read().decode("utf-8", "replace")[:500]
            except Exception:
                text = ""
            finally:
                e.close()
            if log_errors:
                log.warning("Jellyfin %s %s -> HTTP %s: %s", method, path, e.code, text)
            raise JellyfinError("HTTP {}: {}".format(e.code, path), status=e.code, body=text)
        except URLError as e:
            raise JellyfinError("Nelze se pripojit: {}".format(e.reason))
        except (socket.timeout, OSError) as e:
            raise JellyfinError("Chyba spojeni: {}".format(e))
        if not raw:
            return {}
        try:
            return json.loads(raw)
        except ValueError:
            raise JellyfinError("Neplatna odpoved serveru: {}".format(path), body=raw[:200].decode("utf-8", "replace"))

    # ------------------------------------------------------------------
    # Server a přihlášení
    # ------------------------------------------------------------------

    def server_info(self):
        """Veřejné info o serveru (nevyžaduje přihlášení); uloží i verzi."""
        info = self.request("/System/Info/Public", timeout=15)
        self.server_version = info.get("Version", "") or ""
        return info

    def login(self):
        """
        Přihlášení uživatelským jménem. Zkouší pole 'Pw' i 'Password' (různé
        verze Jellyfin). Vrací (user_id, token); při selhání JellyfinError
        s HTTP kódem a tělem poslední odpovědi.
        """
        last = None
        for payload in ({"Username": self.username, "Pw": self.password},
                        {"Username": self.username, "Password": self.password}):
            try:
                result = self.request("/Users/AuthenticateByName", method="POST",
                                      body=payload, timeout=30)
                self.user_id = result["User"]["Id"]
                self.token = result["AccessToken"]
                return self.user_id, self.token
            except JellyfinError as e:
                last = e
                if e.status not in (400, 401):
                    raise
        raise JellyfinError(
            "Prihlaseni selhalo ({}). Zkontroluj URL serveru a prihlasovaci udaje.".format(
                last.status if last else "?"),
            status=last.status if last else None, body=last.body if last else "")

    # ------------------------------------------------------------------
    # API klíče
    # ------------------------------------------------------------------

    def verify_api_key(self, key):
        """
        Ověří klíč na CHRÁNĚNÉM endpointu. /System/Info/Public autentizaci
        nevynucuje (prošel by i vymyšlený klíč), proto /System/Info.
        403 = server klíč přijal, jen účet není administrátor (token běžného uživatele) -> platný;
        neplatný klíč dostane 401.
        """
        try:
            self.request("/System/Info", token=key, timeout=15, log_errors=False)
            return True, "OK"
        except JellyfinError as e:
            if e.status == 403:
                return True, "OK (bez prav administratora)"
            return False, "HTTP {}".format(e.status) if e.status else str(e)

    def list_api_keys(self):
        return self.request("/Auth/Keys").get("Items", [])

    def create_api_key(self, app_name):
        self.request("/Auth/Keys", method="POST", params={"app": app_name})
        mine = [k for k in self.list_api_keys() if k.get("AppName") == app_name]
        if not mine:
            raise JellyfinError("Klic se nepodarilo vytvorit")
        mine.sort(key=lambda k: k.get("DateCreated", ""))
        return mine[-1]["AccessToken"]

    def ensure_api_key(self, app_name="JellyfinKodiSync", saved_key=None):
        """
        Vrátí PLATNÝ trvalý API klíč: uložený -> existující stejnojmenný ->
        nově vytvořený. Vyžaduje předchozí login(). Nastaví self.api_key.

        API klíče smí spravovat jen administrátor. Běžný uživatel (403) dostane místo klíče
        přístupový token z přihlášení – platí, dokud se zařízení na serveru neodhlásí.
        """
        if saved_key and self.verify_api_key(saved_key)[0]:
            self.api_key = saved_key
            return saved_key
        try:
            keys = self.list_api_keys()
        except JellyfinError as e:
            if e.status == 403 and self.token:
                log.info("Ucet neni administrator - misto API klice se pouzije token prihlaseni")
                self.api_key = self.token
                return self.token
            raise
        for k in keys:
            if k.get("AppName") == app_name and k.get("AccessToken"):
                if self.verify_api_key(k["AccessToken"])[0]:
                    self.api_key = k["AccessToken"]
                    return self.api_key
        key = self.create_api_key(app_name)
        ok, msg = self.verify_api_key(key)
        if not ok:
            raise JellyfinError("Novy API klic nefunguje: {}".format(msg))
        self.api_key = key
        return key

    # ------------------------------------------------------------------
    # Knihovna
    # ------------------------------------------------------------------

    def get_libraries(self):
        return self.request("/Users/{}/Views".format(self.user_id)).get("Items", [])

    def get_items(self, item_type, library_ids=None, min_date=None,
                  page_size=2000, fields=None, images=None):
        """
        Generátor – postupně vrací všechny položky daného typu ('Movie' | 'Series'
        | 'Episode'). Při selhání vyhodí JellyfinError (nikdy nevrátí tiše méně).
        fields: přepíše seznam polí ('' = jen Id, nejlehčí dotaz).
        images: přidat značky obrázků (ImageTags, BackdropImageTags) – výchozí u filmů a seriálů při
                plném seznamu polí; u epizod ne (75 000 položek by zbytečně zvětšilo odpověď).
        """
        if images is None:
            images = fields is None and item_type in ("Movie", "Series")
        if fields is None:
            fields = DEFAULT_FIELDS + {"Episode": EPISODE_FIELDS, "Movie": MOVIE_FIELDS}.get(item_type, "")
        base = {
            "IncludeItemTypes": item_type,
            "Recursive": "true",
            "Fields": fields,
            "EnableImages": "false",
            "EnableUserData": "false",
            "Limit": str(page_size),
        }
        if images:
            base.update({"EnableImages": "true", "ImageTypeLimit": "1",
                         "EnableImageTypes": "Primary,Backdrop,Thumb,Logo"})
        if min_date:
            base["MinDateLastSaved"] = min_date

        def fetch(parent_id):
            params = dict(base)
            if parent_id:
                params["ParentId"] = parent_id
            start = 0
            while True:
                params["StartIndex"] = str(start)
                result = self.request("/Users/{}/Items".format(self.user_id),
                                      params=params, timeout=120)
                items = result.get("Items", [])
                for item in items:
                    yield item
                start += len(items)
                if not items or start >= result.get("TotalRecordCount", 0):
                    break

        if library_ids:
            seen = set()
            for lid in library_ids:
                for item in fetch(lid):
                    if item["Id"] not in seen:
                        seen.add(item["Id"])
                        yield item
        else:
            for item in fetch(None):
                yield item

    def count_items(self, item_type):
        """Počet položek daného typu na serveru (jediný malý požadavek, bez stahování seznamu)."""
        result = self.request("/Users/{}/Items".format(self.user_id), params={
            "IncludeItemTypes": item_type, "Recursive": "true", "Limit": "1", "Fields": "",
            "EnableImages": "false", "EnableUserData": "false"}, timeout=60)
        return int(result.get("TotalRecordCount", 0))

    def get_items_by_ids(self, ids, fields="MediaSources,Path", chunk=40):
        """Podrobnosti vybraných položek: {id: položka}. Po dávkách, aby adresa nebyla příliš dlouhá."""
        ids = list(ids)
        out = {}
        for i in range(0, len(ids), chunk):
            part = ids[i:i + chunk]
            result = self.request("/Users/{}/Items".format(self.user_id), params={
                "Ids": ",".join(part), "Fields": fields, "EnableImages": "false",
                "EnableUserData": "false"}, timeout=120)
            for it in result.get("Items", []):
                out[it["Id"]] = it
        return out

    def get_alive_movie_ids(self):
        """ID všech filmů včetně alternativních verzí (zdrojů) sloučených položek."""
        items = list(self.get_items("Movie", fields="MediaSourceCount"))
        alive = {i["Id"] for i in items}
        multi = [i["Id"] for i in items if (i.get("MediaSourceCount") or 0) > 1]
        for item in self.get_items_by_ids(multi, fields="MediaSources").values():
            alive.update(s["Id"] for s in item.get("MediaSources") or [])
        return alive

    def get_item_ids(self, item_type):
        """Množina Id všech položek daného typu (bez filtru knihoven, nejlehčí dotaz)."""
        return set(i["Id"] for i in self.get_items(item_type, fields=""))

    def get_stream_url(self, item_id, api_key=None):
        return "{}/Videos/{}/stream?static=true&api_key={}".format(
            self.server, item_id, api_key or self.api_key)
