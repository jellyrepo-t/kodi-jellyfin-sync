"""
Údržba Kodi video databáze (MyVideos*.db) pro položky z Jellyfin.

Všechny funkce berou otevřené sqlite3 spojení – ať už z Kodi addonu, nebo z PC
appky. Pracují jen se záznamy, které jdou poznat jako Jellyfin (cesta
.../Videos/<id>/ nebo .../Shows/<id>/); cokoliv jiného v knihovně nechávají být.

Typický postup:
    dead_movies, dead_eps = find_dead(conn, alive_movies, alive_episodes)
    n_shows = count_dead_shows(conn, dead_eps, alive_series)   # pro potvrzení
    delete_dead(conn, dead_movies, dead_eps, alive_series)
    rewrite_urls(conn, server_url, api_key)
"""
import logging
import os
import re
import shutil
import sqlite3
import time

log = logging.getLogger("jfcore")

VIDEO_ID_RE = re.compile(r"/Videos/([0-9a-f]{32})")
SHOW_ID_RE = re.compile(r"/Shows/([0-9a-f]{32})")
HOST_RE = re.compile(r"^(https?://[^/]+)/(?:Videos|Shows|Items)/")
KEY_RE = re.compile(r"^[A-Za-z0-9]+$")


def video_id(path):
    """Jellyfin ID videa z cesty .../Videos/<id>/ (nebo None)."""
    m = VIDEO_ID_RE.search(path or "")
    return m.group(1) if m else None


# ----------------------------------------------------------------------
# Záloha databáze (před čištěním a plnou synchronizací)
# ----------------------------------------------------------------------

class BackupError(Exception):
    pass


def list_backups(dest_dir, stem):
    """Zálohy databáze `stem` (např. 'MyVideos131') od nejnovější."""
    if not os.path.isdir(dest_dir):
        return []
    files = [os.path.join(dest_dir, f) for f in os.listdir(dest_dir)
             if f.startswith(stem + "_") and f.endswith(".db")]
    return sorted(files, key=os.path.getmtime, reverse=True)


def newest_backup_age(dest_dir, stem, now=None):
    """Stáří nejnovější zálohy v sekundách (None = žádná není)."""
    files = list_backups(dest_dir, stem)
    return None if not files else (now or time.time()) - os.path.getmtime(files[0])


def backup_database(db_path, dest_dir, label, keep=2, now=None):
    """
    Konzistentní kopie SQLite databáze (funguje i za běhu Kodi a s WAL) do
    dest_dir/<stem>_<label>_<čas>.db. Uchová `keep` nejnovějších záloh.
    Vrací cestu k záloze; při nedostatku místa nebo chybě vyhodí BackupError
    (částečný soubor se vždy smaže, původní databáze se nemění).
    """
    if not db_path or not os.path.isfile(db_path):
        raise BackupError("Databaze neexistuje: {}".format(db_path))
    os.makedirs(dest_dir, exist_ok=True)
    size = os.path.getsize(db_path)
    free = shutil.disk_usage(dest_dir).free
    if free < size * 1.5:
        raise BackupError("Malo mista na zalohu: potreba {} MB, volno {} MB".format(
            int(size * 1.5 / 1048576), int(free / 1048576)))

    stem = os.path.splitext(os.path.basename(db_path))[0]
    stamp = time.strftime("%Y%m%d-%H%M%S", time.localtime(now or time.time()))
    target = os.path.join(dest_dir, "{}_{}_{}.db".format(stem, label, stamp))
    part = target + ".part"
    src = dst = None
    try:
        src = sqlite3.connect("file:{}?mode=ro".format(db_path.replace("\\", "/")), uri=True, timeout=60)
        dst = sqlite3.connect(part)
        src.backup(dst)
        dst.close(); dst = None
        check = sqlite3.connect(part)
        try:
            ok = check.execute("PRAGMA quick_check").fetchone()[0]
        finally:
            check.close()
        if ok != "ok":
            raise BackupError("Zaloha nepresla kontrolou: {}".format(ok))
        os.replace(part, target)
    except BackupError:
        raise
    except Exception as e:
        raise BackupError("Zaloha selhala: {}".format(e))
    finally:
        for c in (src, dst):
            if c is not None:
                try:
                    c.close()
                except Exception:
                    pass
        if os.path.exists(part):
            try:
                os.remove(part)
            except OSError:
                pass
    for old in list_backups(dest_dir, stem)[keep:]:
        try:
            os.remove(old)
        except OSError:
            log.warning("Nelze smazat starou zalohu %s", old)
    return target


# ----------------------------------------------------------------------
# Mrtvé záznamy
# ----------------------------------------------------------------------

# Pojistka: když by se smazalo víc než tohle z knihovny, jde skoro jistě o chybu
# (špatný server, prázdná/jiná knihovna na serveru), ne o skutečně mrtvé záznamy.
# Reálná migrace serveru (staré + nové kopie) bývá kolem 50 %.
MAX_DEAD_FRACTION = 0.9
MIN_ROWS_FOR_GUARD = 50


def is_suspicious(total_rows, dead_rows, max_fraction=MAX_DEAD_FRACTION,
                  min_rows=MIN_ROWS_FOR_GUARD):
    """True, pokud je podezřele velká část Jellyfin záznamů „mrtvá“."""
    return total_rows >= min_rows and dead_rows > total_rows * max_fraction


def _extra_version_ids(conn):
    """Jellyfin ID dalších verzí filmů (videoversion mimo výchozí soubor): {idMovie: [id, ...]}."""
    out = {}
    try:
        rows = conn.execute(
            "SELECT vv.idMedia, p.strPath FROM videoversion vv "
            "JOIN movie m ON m.idMovie=vv.idMedia AND m.idFile<>vv.idFile "
            "JOIN files f ON f.idFile=vv.idFile JOIN path p ON p.idPath=f.idPath "
            "WHERE vv.media_type='movie'").fetchall()
    except Exception:                          # starší Kodi bez tabulky videoversion
        return out
    for movie_id, path in rows:
        vid = video_id(path)
        if vid:
            out.setdefault(movie_id, []).append(vid)
    return out


def plan_version_repairs(conn, alive_movies):
    """
    Filmy s více verzemi, u kterých zmizela jen část verzí: [(idMovie, výchozí soubor,
    [živé soubory], [mrtvé soubory])]. Film, jehož všechny verze zmizely, sem nepatří.
    """
    plan = []
    if not alive_movies:
        return plan
    try:
        rows = conn.execute(
            "SELECT m.idMovie, m.idFile, vv.idFile, p.strPath FROM movie m "
            "JOIN videoversion vv ON vv.idMedia=m.idMovie AND vv.media_type='movie' AND vv.itemType=0 "
            "JOIN files f ON f.idFile=vv.idFile JOIN path p ON p.idPath=f.idPath").fetchall()
    except Exception:
        return plan
    per_movie = {}
    for movie_id, default_file, file_id, path in rows:
        per_movie.setdefault(movie_id, (default_file, []))[1].append((file_id, video_id(path)))
    for movie_id, (default_file, files) in per_movie.items():
        if len(files) < 2:
            continue
        alive = [fid for fid, vid in files if vid and vid in alive_movies]
        dead = [fid for fid, vid in files if vid and vid not in alive_movies]
        if alive and dead:
            plan.append((movie_id, default_file, alive, dead))
    return plan


def repair_versions(conn, alive_movies):
    """
    Filmy s více verzemi: odstraní verze, které už na serveru nejsou, a když zmizela výchozí
    verze, povýší jinou živou. Film, jehož všechny verze zmizely, řeší find_dead/delete_dead.
    Vrací počet odstraněných verzí.
    """
    removed = 0
    for movie_id, default_file, alive, dead in plan_version_repairs(conn, alive_movies):
        if default_file in dead:
            conn.execute("UPDATE movie SET idFile=? WHERE idMovie=?", (alive[0], movie_id))
        for fid in dead:
            conn.execute("DELETE FROM files WHERE idFile=?", (fid,))   # trigger smaže i videoversion
            removed += 1
    conn.commit()
    return removed


def find_dead_with_totals(conn, alive_movies, alive_episodes):
    """
    Jako find_dead, ale vrací i celkové počty rozpoznaných Jellyfin záznamů:
    (dead_movies, dead_episodes, total_movies, total_episodes) – pro is_suspicious().
    """
    dead_movies, total_movies = [], 0
    extra = _extra_version_ids(conn)          # {idMovie: [Jellyfin ID dalších verzí]}
    for row in conn.execute(
            "SELECT m.idMovie, m.idFile, p.strPath FROM movie m "
            "JOIN files f ON f.idFile=m.idFile JOIN path p ON p.idPath=f.idPath"):
        vid = video_id(row[2])
        if vid:
            total_movies += 1
            if alive_movies and vid not in alive_movies and not any(
                    other in alive_movies for other in extra.get(row[0], ())):
                dead_movies.append((row[0], row[1]))

    dead_episodes, total_episodes = [], 0
    for row in conn.execute(
            "SELECT e.idEpisode, e.idFile, e.idShow, p.strPath FROM episode e "
            "JOIN files f ON f.idFile=e.idFile JOIN path p ON p.idPath=f.idPath"):
        vid = video_id(row[3])
        if vid:
            total_episodes += 1
            if alive_episodes and vid not in alive_episodes:
                dead_episodes.append((row[0], row[1], row[2]))
    return dead_movies, dead_episodes, total_movies, total_episodes


def find_dead(conn, alive_movies, alive_episodes):
    """
    Najde filmy a epizody, jejichž Jellyfin ID už na serveru není (typicky po
    přeskenování knihovny nebo migraci serveru, kdy se položky vytvořily znovu
    pod novým ID a staré kopie zůstaly jako nepřehratelné duplicity).
    Prázdná množina "alive" typ NEMAŽE (podezření na selhání při stahování).
    Vrací ([(idMovie, idFile)], [(idEpisode, idFile, idShow)]).
    """
    dm, de, _tm, _te = find_dead_with_totals(conn, alive_movies, alive_episodes)
    return dm, de


def show_jellyfin_id(conn, show_id):
    """Jellyfin ID seriálu z uniqueid, jinak z cesty .../Shows/<id>/ (nebo None)."""
    row = conn.execute(
        "SELECT value FROM uniqueid WHERE media_type='tvshow' AND media_id=? "
        "AND type='jellyfin' LIMIT 1", (show_id,)).fetchone()
    if row and row[0]:
        return row[0]
    for (lp,) in conn.execute(
            "SELECT p.strPath FROM tvshowlinkpath l JOIN path p ON p.idPath=l.idPath "
            "WHERE l.idShow=?", (show_id,)).fetchall():
        m = SHOW_ID_RE.search(lp or "")
        if m:
            return m.group(1)
    return None


def empty_dead_shows(conn, alive_series):
    """Seriály bez epizod, jejichž Jellyfin ID na serveru neexistuje."""
    result = []
    if not alive_series:
        return result
    for (show_id,) in conn.execute(
            "SELECT idShow FROM tvshow WHERE idShow NOT IN (SELECT idShow FROM episode)").fetchall():
        jf_id = show_jellyfin_id(conn, show_id)
        if jf_id and jf_id not in alive_series:
            result.append(show_id)
    return result


def count_dead_shows(conn, dead_episodes, alive_series):
    """Kolik seriálů bude po smazání mrtvých epizod prázdných a mrtvých (odhad pro potvrzení)."""
    if not alive_series:
        return 0
    dead_per_show = {}
    for _e, _f, sid in dead_episodes:
        if sid is not None:
            dead_per_show[sid] = dead_per_show.get(sid, 0) + 1
    count = len(empty_dead_shows(conn, alive_series))
    for sid, n_dead in dead_per_show.items():
        total = conn.execute("SELECT COUNT(*) FROM episode WHERE idShow=?", (sid,)).fetchone()[0]
        if total == n_dead:
            jf_id = show_jellyfin_id(conn, sid)
            if jf_id and jf_id not in alive_series:
                count += 1
    return count


def delete_dead(conn, dead_movies, dead_episodes, alive_series, progress=None, alive_movies=None):
    """
    Smaže mrtvé záznamy po dávkách (commit po 1000). Související data (art, rating,
    uniqueid ...) uklidí Kodiho triggery, zbytek se dočistí. progress(pct, text).
    Vrací slovník s počty: movies, episodes, shows, paths.
    """
    total = max(len(dead_movies) + len(dead_episodes), 1)
    done = [0]

    def tick(n):
        done[0] += n
        if progress:
            progress(int(100 * done[0] / total),
                     "Mazu zastarale zaznamy {}/{}".format(done[0], total))

    step = 1000
    for i in range(0, len(dead_episodes), step):
        chunk = dead_episodes[i:i + step]
        conn.executemany("DELETE FROM episode WHERE idEpisode=?", [(c[0],) for c in chunk])
        conn.executemany("DELETE FROM files WHERE idFile=?", [(c[1],) for c in chunk])
        conn.commit()
        tick(len(chunk))
    for i in range(0, len(dead_movies), step):
        chunk = dead_movies[i:i + step]
        # soubory dalších verzí mizejícího filmu (trigger delete_movie smaže jen řádek výchozí verze)
        try:
            extra_files = []
            for c in chunk:
                extra_files += [(r[0],) for r in conn.execute(
                    "SELECT idFile FROM videoversion WHERE idMedia=? AND media_type='movie' AND idFile<>?",
                    (c[0], c[1]))]
        except Exception:
            extra_files = []
        conn.executemany("DELETE FROM movie WHERE idMovie=?", [(c[0],) for c in chunk])
        conn.executemany("DELETE FROM files WHERE idFile=?", [(c[1],) for c in chunk])
        conn.executemany("DELETE FROM files WHERE idFile=?", extra_files)
        conn.commit()
        tick(len(chunk))

    # Filmy, kterým zmizela jen některá verze (a povýšení nové výchozí verze)
    versions_removed = repair_versions(conn, alive_movies) if alive_movies else 0

    # Prázdné sezóny u dotčených seriálů
    affected = sorted({c[2] for c in dead_episodes if c[2] is not None})
    for i in range(0, len(affected), 500):
        part = affected[i:i + 500]
        ph = ",".join("?" * len(part))
        conn.execute(
            "DELETE FROM seasons WHERE idShow IN (" + ph + ") AND idSeason NOT IN "
            "(SELECT idSeason FROM episode WHERE idSeason IS NOT NULL)", tuple(part))
    conn.commit()

    # Seriály, které zůstaly prázdné a na serveru už nejsou
    dead_shows = empty_dead_shows(conn, alive_series)
    for sid in dead_shows:
        conn.execute("DELETE FROM seasons WHERE idShow=?", (sid,))
        conn.execute("DELETE FROM tvshow WHERE idShow=?", (sid,))
    conn.commit()

    # Sirotci po smazaných záznamech
    conn.execute("DELETE FROM uniqueid WHERE media_type='movie' AND media_id NOT IN (SELECT idMovie FROM movie)")
    conn.execute("DELETE FROM uniqueid WHERE media_type='episode' AND media_id NOT IN (SELECT idEpisode FROM episode)")
    conn.execute("DELETE FROM uniqueid WHERE media_type='tvshow' AND media_id NOT IN (SELECT idShow FROM tvshow)")
    conn.execute("DELETE FROM art WHERE media_type='movie' AND media_id NOT IN (SELECT idMovie FROM movie)")
    conn.execute("DELETE FROM art WHERE media_type='episode' AND media_id NOT IN (SELECT idEpisode FROM episode)")
    conn.execute("DELETE FROM art WHERE media_type='tvshow' AND media_id NOT IN (SELECT idShow FROM tvshow)")
    conn.execute("DELETE FROM art WHERE media_type='season' AND media_id NOT IN (SELECT idSeason FROM seasons)")
    orphan_paths = []
    for idp, sp in conn.execute(
            "SELECT idPath, strPath FROM path WHERE idPath NOT IN (SELECT idPath FROM files) "
            "AND idPath NOT IN (SELECT idPath FROM tvshowlinkpath)"):
        if video_id(sp) or SHOW_ID_RE.search(sp or "") or (sp or "").startswith("jellyfin://tvshow_"):
            orphan_paths.append((idp,))
    conn.executemany("DELETE FROM path WHERE idPath=?", orphan_paths)
    conn.commit()
    return {"movies": len(dead_movies), "episodes": len(dead_episodes),
            "shows": len(dead_shows), "paths": len(orphan_paths), "versions": versions_removed}


# ----------------------------------------------------------------------
# Adresa serveru a API klíč
# ----------------------------------------------------------------------

def rewrite_urls(conn, server, api_key, progress=None):
    """
    Přepíše adresu serveru a API klíč u záznamů z Jellyfin (cesty .../Videos/<id>/,
    .../Shows/<id>/ a náhledy .../Items/<id>/Images/...) na aktuální server a klíč.
    Vrací počet upravených řádků.
    """
    server = (server or "").rstrip("/")
    changed = 0
    if server:
        old_hosts = set()
        for (sp,) in conn.execute("SELECT strPath FROM path WHERE strPath LIKE 'http%'"):
            m = HOST_RE.match(sp or "")
            if m and m.group(1).lower() != server.lower():
                old_hosts.add(m.group(1))
        for (u,) in conn.execute("SELECT url FROM art WHERE url LIKE 'http%/Items/%'"):
            m = HOST_RE.match(u or "")
            if m and m.group(1).lower() != server.lower():
                old_hosts.add(m.group(1))
        for host in sorted(old_hosts):
            if progress:
                progress(50, "Prepisuji adresu {} -> {}".format(host, server))
            n = len(host) + 1
            changed += conn.execute(
                "UPDATE path SET strPath = ? || substr(strPath, ?) WHERE strPath LIKE ? "
                "AND (strPath LIKE '%/Videos/%' OR strPath LIKE '%/Shows/%')",
                (server, n, host + "/%")).rowcount
            changed += conn.execute(
                "UPDATE art SET url = ? || substr(url, ?) WHERE url LIKE ?",
                (server, n, host + "/%")).rowcount
        conn.commit()

    if api_key:
        old_keys = set()
        for (k,) in conn.execute(
                "SELECT DISTINCT substr(strFilename, instr(strFilename, 'api_key=') + 8) "
                "FROM files WHERE strFilename LIKE 'stream?%api_key=%'"):
            old_keys.add(k)
        for (k,) in conn.execute(
                "SELECT DISTINCT substr(url, instr(url, 'api_key=') + 8) "
                "FROM art WHERE url LIKE '%/Images/%api_key=%'"):
            old_keys.add(k)
        for k in sorted(old_keys):
            if k == api_key or not KEY_RE.match(k or ""):
                continue
            if progress:
                progress(80, "Prepisuji API klic ...")
            changed += conn.execute(
                "UPDATE files SET strFilename = replace(strFilename, ?, ?) "
                "WHERE strFilename LIKE 'stream?%api_key=' || ?",
                ("api_key=" + k, "api_key=" + api_key, k)).rowcount
            changed += conn.execute(
                "UPDATE art SET url = replace(url, ?, ?) "
                "WHERE url LIKE '%/Images/%api_key=' || ?",
                ("api_key=" + k, "api_key=" + api_key, k)).rowcount
        conn.commit()
    return changed
