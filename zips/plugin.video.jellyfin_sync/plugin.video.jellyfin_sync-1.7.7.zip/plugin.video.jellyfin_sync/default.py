"""
Jellyfin Sync – vstupní bod addonu
"""
import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

try:
    from urllib.parse import parse_qsl, urlencode
except ImportError:
    from urlparse import parse_qsl
    from urllib import urlencode

ADDON = xbmcaddon.Addon()
ADDON_ID = 'plugin.video.jellyfin_sync'
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
BASE_URL = sys.argv[0] if sys.argv else 'plugin://' + ADDON_ID


def build_url(action):
    return BASE_URL + '?action=' + action


def _icon(name):
    import os
    return os.path.join(ADDON.getAddonInfo('path'), 'resources', 'media', 'icons', name + '.png')


def _local_time(value):
    """Čas uložený v UTC ('...Z') nebo místní ('...T...') -> 'RRRR-MM-DD HH:MM' v místním čase."""
    if not value:
        return ''
    import calendar
    import time as _time
    try:
        if value.endswith('Z'):
            stamp = _time.localtime(calendar.timegm(_time.strptime(value, '%Y-%m-%dT%H:%M:%SZ')))
        else:
            stamp = _time.strptime(value[:19], '%Y-%m-%dT%H:%M:%S')
        return _time.strftime('%d.%m.%Y %H:%M', stamp)
    except ValueError:
        return value.replace('T', ' ')


def show_menu():
    from resources.lib.sync_engine import load_state
    state = load_state()
    last_full = _local_time(state.get('last_full_sync')) or 'zatím neproběhla'
    last_quick = _local_time(state.get('last_sync')) or 'zatím neproběhla'

    if ADDON.getSetting('auto_sync') != 'false':
        try:
            hh = int(ADDON.getSetting('sync_hour') or '2')
            mm = int(ADDON.getSetting('sync_minute') or '0')
        except ValueError:
            hh, mm = 2, 0
        auto = ('Automatická synchronizace: zapnuta',
                'Rychlá aktualizace 30 s po startu Kodi a plná synchronizace každý den v {}:{:02d}. '
                'Změníš v Nastavení.'.format(hh, mm))
    else:
        auto = ('Automatická synchronizace: vypnuta',
                'Doplněk knihovnu sám neaktualizuje (např. ji plní PC appka). Zapneš v Nastavení.')

    items = []
    try:
        from resources.lib import jobs
        running = jobs.running_status()
        last_job = jobs.read_status().get('last')
    except Exception:
        running, last_job = None, None
    if running:
        items.append(('job_status', 'Probíhá: {} – {} %'.format(running.get('label', ''), running.get('pct', 0)),
                      running.get('msg', ''), 'status'))
    elif last_job:
        items.append(('job_status', 'Poslední úloha: {} – {}'.format(
                          last_job.get('label', ''), 'hotovo' if last_job.get('ok') else 'chyba'),
                      '{}  {}'.format(last_job.get('finished', ''), last_job.get('summary', '')), 'status'))

    items += [
        ('settings', auto[0], auto[1], 'schedule'),
        ('full_sync', 'Plná synchronizace',
         'Načte z Jellyfinu celou knihovnu – filmy včetně verzí, seriály a epizody. Běží na pozadí, '
         'Kodi můžeš dál používat.[CR][CR]Naposledy: {}'.format(last_full), 'sync'),
        ('incremental_sync', 'Rychlá aktualizace',
         'Přidá jen to, co na serveru přibylo od poslední synchronizace, a uklidí smazané položky.'
         '[CR][CR]Naposledy: {}'.format(last_quick), 'quick'),
        ('repair', 'Vyčistit knihovnu',
         'Odstraní filmy a epizody, které už na serveru nejsou (nepřehratelné duplicity), a opraví adresu '
         'serveru. Před mazáním se zeptá a zazálohuje databázi.', 'clean'),
        ('fix_db', 'Opravit databázi',
         'Doplní chybějící sezóny, propojení seriálů a typy složek, když se něco v knihovně nezobrazuje.', 'repair'),
        ('skin', 'Vzhled: Arctic Fuse 3',
         'Nainstaluje skin Arctic Fuse 3 s přednastavenou úvodní obrazovkou a TMDb widgety – lehké '
         '(pro TV boxy a Google TV) nebo plné nastavení.', 'skin'),
        ('fix_http2', 'Oprava zasekávání po zastavení filmu',
         'Kodi 21.2 se po zastavení filmu z Jellyfinu může zaseknout. Oprava vypne HTTP/2 '
         'v advancedsettings.xml, projeví se po restartu Kodi.', 'fix'),
        ('wizard', 'Průvodce nastavením',
         'Server a přihlášení, zda plnit knihovnu, oprava pro Kodi 21.2 a vzhled – krok za krokem.', 'wizard'),
        ('settings', 'Nastavení',
         'Server, přihlašovací údaje, čas automatické synchronizace a automatický úklid.', 'settings'),
    ]

    xbmcplugin.setPluginCategory(HANDLE, 'Jellyfin Sync')
    xbmcplugin.setContent(HANDLE, 'files')

    for action, label, desc, icon in items:
        li = xbmcgui.ListItem(label=label)
        try:
            tag = li.getVideoInfoTag()
            tag.setPlot(desc)
        except Exception:
            li.setInfo('video', {'plot': desc})
        path = _icon(icon)
        li.setArt({'icon': path, 'thumb': path})
        xbmcplugin.addDirectoryItem(HANDLE, build_url(action), li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def _add_kodi_source(content_type, name, path):
    import os
    try:
        import xbmcvfs
        userdata = xbmcvfs.translatePath('special://masterprofile/')
    except Exception:
        userdata = xbmc.translatePath('special://masterprofile/')

    sources_file = os.path.join(userdata, 'sources.xml')
    try:
        if os.path.exists(sources_file):
            with open(sources_file, 'r', encoding='utf-8') as f:
                xml = f.read()
        else:
            xml = '<sources>\n<video>\n<default pathversion="1"></default>\n</video>\n</sources>'
    except Exception:
        xml = '<sources>\n<video>\n<default pathversion="1"></default>\n</video>\n</sources>'

    from xml.sax.saxutils import escape
    name, path = escape(name), escape(path)            # adresa s & nebo < by jinak rozbila sources.xml
    if '<path pathversion="1">{}</path>'.format(path) in xml:
        return

    source_xml = (
        '    <source>\n'
        '        <name>{}</name>\n'
        '        <path pathversion="1">{}</path>\n'
        '        <allowsharing>true</allowsharing>\n'
        '    </source>\n'
    ).format(name, path)

    if '</video>' in xml:
        xml = xml.replace('</video>', source_xml + '</video>')
    else:
        xml = xml.replace('</sources>', '<video>\n' + source_xml + '</video>\n</sources>')

    try:
        with open(sources_file, 'w', encoding='utf-8') as f:
            f.write(xml)
        xbmc.log('[JellyfinSync] Pridan zdroj: ' + name, xbmc.LOGINFO)
    except Exception as e:
        xbmc.log('[JellyfinSync] Chyba zdroje: ' + str(e), xbmc.LOGWARNING)


def fix_db():
    import sqlite3, glob, os
    try:
        from resources.lib import jobs
        if jobs.running_status():
            xbmcgui.Dialog().ok('Jellyfin Sync', 'Prave bezi uloha na pozadi. Pockej, az dobehne.')
            return
    except Exception:
        pass
    try:
        import xbmcvfs
        db_dir = xbmcvfs.translatePath('special://database/')
    except Exception:
        db_dir = xbmc.translatePath('special://database/')

    dbs = glob.glob(os.path.join(db_dir, 'MyVideos*.db'))
    if not dbs:
        xbmcgui.Dialog().ok('Chyba', 'Databaze nenalezena')
        return
    db_path = max(dbs, key=lambda p: int(''.join(c for c in os.path.basename(p) if c.isdigit()) or '0'))

    # oprava přepisuje řádky v databázi Kodi – bez zálohy se nespustí (stejně jako čištění)
    try:
        from resources.lib import jobs
        from resources.lib.jfcore import maintenance
        maintenance.backup_database(db_path, jobs.BACKUP_DIR, 'fixdb', keep=jobs.BACKUP_KEEP)
    except Exception as e:
        xbmcgui.Dialog().ok('Jellyfin Sync', 'Zaloha databaze selhala, nic se nemeni:\n' + str(e))
        return

    dlg = xbmcgui.DialogProgress()
    dlg.create('Oprava databaze', 'Pripojuji...')

    try:
        conn = sqlite3.connect(db_path, timeout=30)
        conn.row_factory = sqlite3.Row
        conn.execute('PRAGMA journal_mode=WAL')

        # Diagnostika
        dlg.update(5, 'Diagnostika...')
        ep_total = conn.execute('SELECT COUNT(*) FROM episode').fetchone()[0]
        ep_with_season = conn.execute('SELECT COUNT(*) FROM episode WHERE idSeason IS NOT NULL AND idSeason != 0').fetchone()[0]
        seasons_total = conn.execute('SELECT COUNT(*) FROM seasons').fetchone()[0]
        xbmc.log('[JellyfinSync fix_db] ep={} ep_season={} seasons={}'.format(ep_total, ep_with_season, seasons_total), xbmc.LOGINFO)

        # (Dřívější "Oprava 0" prohazovala c12/c13 u VŠECH epizod, jakmile jich bylo >100
        # s velkým číslem sezóny – při každém spuštění tak rozbila i správně uložené seriály.
        # Číslování sezón/dílů teď opravuje synchronizace z čísel na serveru.)

        # Oprava 1: seasons - vytvor zaznamy pro vsechny show/season kombinace
        dlg.update(15, 'Vytvarim sezony ({} epizod)...'.format(ep_total))
        all_combos = conn.execute(
            'SELECT DISTINCT idShow, CAST(c12 AS INTEGER) as snum FROM episode WHERE c12 IS NOT NULL AND c12 != ""'
        ).fetchall()

        season_map = {}
        for row in all_combos:
            show_id = row['idShow']
            season_num = row['snum'] if row['snum'] is not None else 0
            key = (show_id, season_num)
            existing = conn.execute(
                'SELECT idSeason FROM seasons WHERE idShow=? AND season=?', (show_id, season_num)
            ).fetchone()
            if existing:
                season_map[key] = existing['idSeason']
            else:
                cur = conn.execute('INSERT INTO seasons (idShow, season) VALUES (?, ?)', (show_id, season_num))
                season_map[key] = cur.lastrowid

        # Prirad idSeason epizodm
        dlg.update(40, 'Priraduji sezony epizodm ({})...'.format(len(season_map)))
        for (show_id, season_num), season_id in season_map.items():
            conn.execute(
                'UPDATE episode SET idSeason=? WHERE idShow=? AND CAST(c12 AS INTEGER)=? AND (idSeason IS NULL OR idSeason=0)',
                (season_id, show_id, season_num)
            )

        # Oprava 2: tvshowlinkpath
        dlg.update(60, 'Opravuji propojeni serialu...')
        shows_no_link = conn.execute(
            'SELECT idShow FROM tvshow WHERE idShow NOT IN (SELECT idShow FROM tvshowlinkpath)'
        ).fetchall()
        for row in shows_no_link:
            show_id = row['idShow']
            fake_path = 'jellyfin://tvshow_{}/'.format(show_id)
            conn.execute(
                "INSERT OR IGNORE INTO path (strPath, strContent, strScraper, noUpdate) VALUES (?, 'tvshows', 'metadata.local', 1)",
                (fake_path,)
            )
            pid = conn.execute('SELECT idPath FROM path WHERE strPath=?', (fake_path,)).fetchone()['idPath']
            conn.execute('INSERT OR IGNORE INTO tvshowlinkpath (idShow, idPath) VALUES (?, ?)', (show_id, pid))

        # Oprava 3a: playCount - NULL = neshlédnuto, 0 = shlédnuto
        # COUNT(playCount) pocita non-NULL, proto 0 = "shlédnuto 0x" = shlédnuto!
        dlg.update(68, 'Opravuji sledovanost (playCount)...')
        pc_fixed = conn.execute('UPDATE files SET playCount=NULL WHERE playCount=0').rowcount
        xbmc.log('[JellyfinSync fix_db] playCount opraven: {}'.format(pc_fixed), xbmc.LOGINFO)

        # Oprava 3b: videoversion itemType - musi byt 0 (default), ne 1 (extra)
        dlg.update(70, 'Opravuji videoversion itemType...')
        vv_fixed = conn.execute('UPDATE videoversion SET itemType=0 WHERE itemType=1').rowcount
        xbmc.log('[JellyfinSync fix_db] videoversion itemType opraveno: {}'.format(vv_fixed), xbmc.LOGINFO)

        # Oprava 4: strContent
        dlg.update(75, 'Opravuji typy cest...')
        conn.execute(
            "UPDATE path SET strContent='movies', strScraper='metadata.local', noUpdate=1 "
            "WHERE idPath IN (SELECT DISTINCT f.idPath FROM files f JOIN movie m ON m.idFile=f.idFile) "
            "AND (strContent='' OR strContent IS NULL OR strContent='none')"
        )
        conn.execute(
            "UPDATE path SET strContent='tvshows', strScraper='metadata.local', noUpdate=1 "
            "WHERE idPath IN (SELECT idPath FROM tvshowlinkpath) "
            "AND (strContent='' OR strContent IS NULL OR strContent='none')"
        )

        # Oprava 4: smazani prazdnych sezony (0 epizod)
        dlg.update(85, 'Mazu prazdne sezony...')
        empty = conn.execute(
            'SELECT s.idSeason FROM seasons s '
            'LEFT JOIN episode e ON e.idSeason = s.idSeason '
            'WHERE e.idEpisode IS NULL'
        ).fetchall()
        for row in empty:
            conn.execute('DELETE FROM seasons WHERE idSeason=?', (row['idSeason'],))
        xbmc.log('[JellyfinSync fix_db] Smazano prazdnych sezon: {}'.format(len(empty)), xbmc.LOGINFO)

        # Oprava 5: sources.xml
        dlg.update(88, 'Pridavam zdroje...')
        server = ADDON.getSetting('server_url').rstrip('/')
        if server:
            _add_kodi_source('movies', 'Jellyfin Filmy', server + '/Videos/')
            _add_kodi_source('tvshows', 'Jellyfin Serialy', server + '/Shows/')

        conn.commit()

        ep2 = conn.execute('SELECT COUNT(*) FROM episode WHERE idSeason IS NOT NULL AND idSeason != 0').fetchone()[0]
        seasons2 = conn.execute('SELECT COUNT(*) FROM seasons').fetchone()[0]
        links2 = conn.execute('SELECT COUNT(*) FROM tvshowlinkpath').fetchone()[0]
        movies2 = conn.execute('SELECT COUNT(*) FROM movie').fetchone()[0]
        conn.close()
        dlg.close()

        xbmc.executebuiltin('UpdateLibrary(video)')
        xbmcgui.Dialog().ok('Oprava dokoncena',
            'Filmu: {}  |  Serialu: {}\nEpizod: {} ({} se sezonou)\nSezony: {}  |  Propojeni: {}'.format(
                movies2, len(all_combos), ep_total, ep2, seasons2, links2))

    except Exception as e:
        dlg.close()
        import traceback
        xbmc.log('[JellyfinSync fix_db] ' + traceback.format_exc(), xbmc.LOGERROR)
        xbmcgui.Dialog().ok('Chyba opravy', str(e))


def repair_db():
    """Smaže záznamy s neexistujícím Jellyfin ID a opraví adresy/API klíč."""
    from resources.lib.sync_engine import SyncEngine, SyncProgress

    title = 'Jellyfin - Cisteni databaze'
    dlg = xbmcgui.DialogProgress()
    dlg.create(title, 'Inicializuji...')
    state = {'pct': 0, 'msg': ''}

    # čištění maže – bez zálohy databáze se nespustí
    try:
        from resources.lib import jobs
        from resources.lib.jfcore import maintenance
        from resources.lib.kodidb import find_kodi_db
        dlg.update(1, 'Zalohuji databazi...')
        maintenance.backup_database(find_kodi_db(), jobs.BACKUP_DIR, 'repair', keep=jobs.BACKUP_KEEP)
    except Exception as e:
        dlg.close()
        xbmcgui.Dialog().ok('Jellyfin Sync', 'Zaloha databaze selhala, nic se nemaze:\n' + str(e))
        return

    def on_progress(pct, msg=''):
        state['pct'] = int(pct)
        if msg:
            state['msg'] = msg
        dlg.update(state['pct'], state['msg'])

    def on_message(msg):
        xbmc.log('[JellyfinSync] ' + msg, xbmc.LOGINFO)

    def confirm(n_movies, n_eps, n_shows):
        dlg.close()
        ok = xbmcgui.Dialog().yesno(
            'Jellyfin - Cisteni databaze',
            'Na serveru uz neexistuji (nejdou prehrat):\n'
            '{} filmu, {} epizod, {} serialu.\n'
            'Smazat je a opravit adresy serveru a API klic?'.format(n_movies, n_eps, n_shows))
        if ok:
            dlg.create(title, 'Cistim databazi...')
        return ok

    try:
        engine = SyncEngine(progress=SyncProgress(on_message=on_message, on_progress=on_progress))
        stats = engine.repair(confirm=confirm)
    except Exception as e:
        dlg.close()
        import traceback
        xbmc.log('[JellyfinSync repair] ' + traceback.format_exc(), xbmc.LOGERROR)
        xbmcgui.Dialog().ok('Jellyfin Sync - Chyba', str(e))
        return
    dlg.close()

    if stats is None:
        return
    if stats.get('refused'):
        xbmcgui.Dialog().ok(
            'Cisteni odmitnuto',
            'Server vratil podezrele malo polozek, takze by se smazala\n'
            'skoro cela knihovna. Nic se nezmenilo.\n'
            'Zkontroluj pripojeni k Jellyfinu a zkus to znovu.')
        return
    xbmc.executebuiltin('UpdateLibrary(video)')
    xbmcgui.Dialog().ok(
        'Cisteni dokonceno',
        'Smazano: {} filmu, {} epizod, {} serialu\n'
        'Prepsano adres/klicu: {}\n'
        'Doporucuji restartovat Kodi.'.format(
            stats['movies'], stats['episodes'], stats['shows'], stats.get('rewritten', 0)))


def run_sync(full=True):
    from resources.lib.sync_engine import SyncEngine, SyncProgress

    title = 'Jellyfin - Plna synchronizace' if full else 'Jellyfin - Rychla aktualizace'
    progress_dlg = xbmcgui.DialogProgress()
    progress_dlg.create(title, 'Inicializuji...')

    current_pct = [0]
    current_msg = ['']

    def on_progress(pct, msg=''):
        if progress_dlg.iscanceled():
            return
        current_pct[0] = int(pct)
        if msg:
            current_msg[0] = msg
        progress_dlg.update(current_pct[0], current_msg[0])

    def on_message(msg):
        xbmc.log('[JellyfinSync] ' + msg, xbmc.LOGINFO)
        if progress_dlg.iscanceled():
            return
        progress_dlg.update(current_pct[0], current_msg[0] + '\n' + msg)

    prog = SyncProgress(on_message=on_message, on_progress=on_progress)
    error_msg = [None]

    try:
        engine = SyncEngine(progress=prog)
        if full:
            engine.full_sync()
        else:
            engine.incremental_sync()
    except Exception as e:
        xbmc.log('[JellyfinSync] CHYBA: ' + str(e), xbmc.LOGERROR)
        error_msg[0] = str(e)
    finally:
        progress_dlg.close()

    if error_msg[0]:
        xbmcgui.Dialog().ok('Jellyfin Sync - Chyba', error_msg[0])
    elif not progress_dlg.iscanceled():
        xbmc.executebuiltin('UpdateLibrary(video)')


def start_background(kind):
    """Zadá úlohu službě na pozadí; když služba neběží, provede se v popředí jako dřív."""
    from resources.lib import jobs
    label = jobs.LABELS[kind]
    result = jobs.request_job(kind)
    dlg = xbmcgui.Dialog()
    if result == 'queued':
        dlg.notification('Jellyfin Sync', '{} bezi na pozadi'.format(label),
                        xbmcgui.NOTIFICATION_INFO, 4000)
    elif result == 'busy':
        running = jobs.running_status() or {}
        dlg.notification('Jellyfin Sync', 'Uz bezi: {} ({} %)'.format(
            running.get('label', 'jina uloha'), running.get('pct', 0)),
            xbmcgui.NOTIFICATION_WARNING, 5000)
    else:
        xbmc.log('[JellyfinSync] Sluzba neběží, spoustim v popredi: ' + kind, xbmc.LOGWARNING)
        if kind == 'repair':
            repair_db()
        else:
            run_sync(full=(kind == 'full'))


def show_job_status():
    from resources.lib import jobs
    st = jobs.read_status()
    running = jobs.running_status()
    if running:
        text = '{}\n{} %\n{}'.format(running.get('label', ''), running.get('pct', 0), running.get('msg', ''))
    elif st.get('last'):
        last = st['last']
        text = '{}\n{}\n{}'.format(last.get('label', ''), last.get('finished', ''), last.get('summary', ''))
    else:
        text = 'Zadna uloha zatim neprobehla.'
    xbmcgui.Dialog().ok('Jellyfin Sync', text)


def play_tmdb(params):
    """Přehrávač pro TMDb Helper: najde film / epizodu na Jellyfinu podle TMDb ID a přehraje ji."""
    from resources.lib import picker

    def clean(key):
        value = (params.get(key) or '').strip()
        return '' if value.startswith('{') or value.lower() == 'none' else value   # nevyplněný zástupný text

    def fail(message):
        if message:
            xbmcgui.Dialog().notification('Jellyfin Sync', message, xbmcgui.NOTIFICATION_WARNING, 5000)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())

    picker.busy(True)
    try:
        jf = picker.connect()
        if params.get('type') == 'episode':
            _item, options = picker.episode_options(jf, clean('season'), clean('episode'),
                                                    tmdb=clean('tmdb'), tvdb=clean('tvdb'))
        else:
            _group, options = picker.movie_options(jf, None, clean('tmdb'), clean('imdb'), clean('year'))
    except picker.NotFound as e:
        picker.busy(False)
        return fail(str(e))
    except Exception as e:
        picker.busy(False)
        xbmc.log('[JellyfinSync play_tmdb] {}'.format(e), xbmc.LOGWARNING)
        return fail('Nelze se pripojit k Jellyfinu: {}'.format(e))
    picker.busy(False)

    source_id = picker.choose(options)
    if source_id is None:
        return fail(None)
    xbmcplugin.setResolvedUrl(HANDLE, True, xbmcgui.ListItem(path=picker.stream_url(jf, source_id)))


def main():
    params = dict(parse_qsl(sys.argv[2][1:] if len(sys.argv) > 2 else ''))
    action = params.get('action', 'menu')

    if action == 'menu':
        if not ADDON.getSetting('server_url'):          # první spuštění: nejdřív průvodce
            from resources.lib import wizard
            wizard.run(ADDON, start_full_sync=lambda: start_background('full'))
        show_menu()
    elif action == 'wizard':
        from resources.lib import wizard
        wizard.run(ADDON, start_full_sync=lambda: start_background('full'))
    elif action == 'skin':
        from resources.lib import skin_setup
        skin_setup.run_interactive()
    elif action == 'fix_http2':
        from resources.lib import kodi_fixes
        kodi_fixes.offer_fix(xbmcgui.Dialog(), from_menu=True)
    elif action == 'full_sync':
        start_background('full')
    elif action == 'incremental_sync':
        start_background('incremental')
    elif action == 'fix_db':
        fix_db()
    elif action == 'repair':
        start_background('repair')
    elif action == 'job_status':
        show_job_status()
    elif action == 'play_tmdb':
        play_tmdb(params)

    elif action == 'settings':
        ADDON.openSettings()
    else:
        show_menu()


if __name__ == '__main__':
    main()
